import {combineReducers} from 'redux'
import activityReducer from './activityReducer'
import authReducer from './authReducer.js'
import {firestoreReducer} from 'redux-firestore'
import {firebaseReducer} from 'react-redux-firebase'

const allReducers = combineReducers({
	activitys: activityReducer,
	auth:authReducer,
	firestore: firestoreReducer,
	firebase : firebaseReducer

})

export default allReducers;