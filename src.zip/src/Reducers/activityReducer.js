const initState = {
  activitys: [
    {
      assignError: null,
      signUpError: null,
      activityError: null,
      deleateError: null,
      roll: null,
      publishError: null
    }
  ]
};

const activityReducer = (state = initState, action) => {
  switch (action.type) {
    case "CREATE_ACTIVITY":
      return {
        ...state,
        activityError: "Activity Sucessfully Created"
        //"Your can close pop up now"
      };
    case "CREATE_ACTIVITY_ERROR":
      return {
        ...state,
        activityError: "Error Creating Activity, Please try again"
      };
    case "CREATE_ACTIVITY_RESET":
      return {
        ...state,
        activityError: null
      };
    case "ASSIGN_ACTIVITY_RESET":
      return {
        ...state,
        assignError: null
      };
    case "DELETE_ASSIGN_ACTIVITY_RESET":
      return {
        ...state,
        deleateError: null
      };
    case "CREATE_ACTIVITY_ERROR_ID_EXISTS":
      return {
        ...state,
        activityError: "ID Already Exists"
      };
    case "ASSIGN_ACTIVITY":
      return {
        ...state,
        assignError: "Student Assigned. You can close the pop up now"
      };
    case "ASSIGN_ACTIVITY_ERROR_NO_ACTIVITY":
      return {
        ...state,
        assignError: "Activity Does Not Exist"
      };
    case "ASSIGN_ACTIVITY_ERROR_NO_STUDENT":
      return {
        ...state,
        assignError: "Student Does Not Exist"
      };
    case "ASSIGN_DELETE":
      return {
        ...state,
        deleateError: "Student Admin Deleted. You can close the pop up now"
      };
    case "ASSIGN_DELETE_ERROR_NO_ACTIVITY":
      return {
        ...state,
        deleateError: "Activity or Student Does Not Exist"
      };
    case "ASSIGN_DELETE_ERROR_NO_STUDENT":
      return {
        ...state,
        deleateError: "Student Does Not Exist"
      };
    case "ROLL_CALL_SUSCESS":
      return {
        ...state,
        roll: "Sucessfully Graded"
      };
    case "ROLL_CALL_ERROR":
      return {
        ...state,
        roll: "Error Grading "
      };
    case "ASSIGN_DELETE_SUCCESS":
      return {
        ...state,
        deleateError: "User admin deleted. You can close the pop up now. "
      };
    case "SIGN_UP_SUCCESS":
      return {
        ...state,
        signUpError: "Successfully signed up."
      };
    case "CLEAR_SIGNUP":
      return {
        ...state,
        signUpError: null
      };
    case "CREATE_ACTIVITY_DATE_ERROR":
      return {
        ...state,
        activityError: "Start date can't be after End Date "
      };
    case "CREATE_ACTIVITY_ADDRESS_EMPTY":
      return {
        ...state,
        activityError: "Please fill out the Address"
      };
    case "PUBLISH_SUSCESS":
      return {
        ...state,
        publishError: "Activity Published Successfully"
      };
    case "PUBLISH_ERROR":
      return {
        ...state,
        publishError: "Error on Publish"
      };
    case "CLEAR_PUBLISHED":
      return {
        ...state,
        publishError: null
      };
    case "DELEATE_SUSCESS":
      return {
        ...state,
        publishError: "Activity Deleted Successfully"
      };
    default:
      return state;
  }
};

export default activityReducer;
