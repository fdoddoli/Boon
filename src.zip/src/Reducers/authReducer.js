const initState = {
  activitys: [
    {
      authError: null,
      fpasswordError: null
    }
  ]
};

const authReducer = (state = initState, action) => {
  switch (action.type) {
    case "SIGNUP_SUCESS":
      return {
        ...state,
        authError: null
      };
    case "SIGNUP_ERROR":
      return {
        ...state,
        authError: action.err.message
      };
    case "SCHOOL_DOES_NOT_EXIST":
      return {
        ...state,
        authError: "School Does Not Exist"
      };
    case "FORGOT_PASSWORD_SENT":
      return {
        ...state,
        fpasswordError: "Email Sent. Check your Inbox"
      };
    case "FORGOT_PASSWORD_ERR":
      return {
        ...state,
        fpasswordError: action.err.message
      };
    default:
      return state;
  }
};
export default authReducer;
