import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "../../../activityDetaile";
import Loader from "react-loader-spinner";

class PUActivityList extends Component {
  render() {
    const { activitys, profile } = this.props;
    if (activitys != null) {
      return (
        <div className="pprruueebbaa">
          <ul className="ulllll">
            {activitys &&
              activitys.map(activity => {
                if (
                  profile.schoolCode == activity.school &&
                  activity.status == "Autorizado"
                ) {
                  return (
                    <Link to={"/activity/" + activity.id}>
                      <ActivityDetaile activity={activity} key={activity.id} />
                    </Link>
                  );
                }
              })}
          </ul>
        </div>
      );
    } else {
      return (
        <div className="spinner">
          <Loader
            type="TailSpin"
            color="rgba(231, 91, 16, 1.0)"
            height={150}
            width={150}
          />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.Actividades,
    profile: state.firebase.profile
  };
}
export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "Actividades" }])
)(PUActivityList);
