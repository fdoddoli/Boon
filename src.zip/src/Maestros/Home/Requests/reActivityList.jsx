import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "../../../activityDetaile";

class ReActivityList extends Component {
  render() {
    const { activitys } = this.props;
    const { profile } = this.props;

    return (
      <div className="pprruueebbaa">
        <ul className="ulllll">
          {activitys &&
            activitys.map(activity => {
              if (
                profile.schoolCode == activity.school &&
                activity.status == "Enviado"
              ) {
                return (
                  <Link to={"/activity/" + activity.id}>
                    <ActivityDetaile activity={activity} key={activity.id} />
                  </Link>
                );
              }
            })}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.Actividades,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "Actividades" }])
)(ReActivityList);
