import React, { Component } from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { NavLink } from "react-router-dom";
import menuBar from "../../img/menuBar.png";
import { connect } from "react-redux";
import "../../HomeTest.css";
import triangle from "../../img/triangleDropDown.png";
import firebase from "firebase";
import {
  ActionItem,
  DropDownMenu,
  DropDownDirection
} from "react-dropdown-advanced";
import Popup from "reactjs-popup";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from "@material-ui/pickers";
import {
  NotificationContainer,
  NotificationManager
} from "react-notifications";
import "react-notifications/lib/notifications.css";
import { createActivity } from "../../Actions/activityActions";
import { assignActivity } from "../../Actions/activityActions";
import { clearActivity } from "../../Actions/activityActions";
import { deleateUserAdmin } from "../../Actions/activityActions";
import { clearAssign } from "../../Actions/activityActions";
import { clearDelete } from "../../Actions/activityActions";
import { firestoreConnect } from "react-redux-firebase";
import AssignedList from "./Assigned/assignedList";
import PUActivityList from "./Published/puActivityList";
import ReActivityList from "./Requests/reActivityList";
import puActivityInfo from "./Published/puActivityInfo";
import FileUploader from "react-firebase-file-uploader";

const homeMaestroRoutes = [
  {
    path: "/published",
    exact: true,
    sidebar: () => <div>1</div>,
    main: () => <PUActivityList />
  },
  {
    path: "/published/requests",
    exact: true,
    sidebar: () => <div>2</div>,
    main: () => <ReActivityList />
  },
  {
    path: "/published/assigned",
    exact: true,
    sidebar: () => <div>3</div>,
    main: () => <AssignedList />
  },
  {
    path: "/activity/:id",
    exact: true,
    main: puActivityInfo
  }
];

class HomeScreenMaestro extends Component {
  constructor(props) {
    super(props);
    this.state = {
      image: "",
      avatar: "",
      avatarPDF: "",
      username: "",
      isUploading: false,
      currentSignUps: 0,
      progress: 0,
      avatarURL: "",
      title: "",
      desc: "",
      size: "",
      hours: 0,
      address: "",
      startDate: null,
      endDate: null,
      time: "",
      pdf: "",
      repeat: "",
      school: "",
      student: "",
      activity: "",
      status: "Autorizado",
      createdby: "",
      frequency: "Weekly",
      open: false,
      open2: false,
      open3: false
    };
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.openModal2 = this.openModal2.bind(this);
    this.closeModal2 = this.closeModal2.bind(this);
    this.openModal3 = this.openModal3.bind(this);
    this.closeModal3 = this.closeModal3.bind(this);
  }
  openModal() {
    this.setState({ open: true });
  }
  closeModal() {
    this.setState({ open: false });
  }
  openModal2() {
    this.setState({ open2: true });
  }
  closeModal2() {
    this.setState({ open2: false });
  }
  openModal3() {
    this.setState({ open3: true });
  }
  closeModal3() {
    this.setState({ open3: false });
  }
  logout = () => {
    firebase.auth().signOut();
  };
  getDynamicItems = () => {
    var arr: DropDownItemBase[] = [];
    arr.push(new ActionItem("logout", "Logout", ""));

    return arr;
  };
  handleChange = e => {
    this.setState({
      [e.target.name]:
        e.target.type === "number" ? parseInt(e.target.value) : e.target.value
    });
  };
  handleSubmit = e => {
    this.props.createActivity(this.state);
    e.preventDefault();
  };
  handleSubmit2 = e => {
    e.preventDefault();
    this.props.assignActivity(this.state);
  };
  handleSubmit5 = e => {
    this.setState({ student: "" });
    this.setState({ activity: "" });
    this.props.clearAssign(this.state);
  };
  handleSubmit6 = e => {
    this.setState({ student: "" });
    this.setState({ activity: "" });
    this.props.clearDelete(this.state);
  };
  handleSubmit4 = e => {
    e.preventDefault();
    this.props.deleateUserAdmin(this.state);
  };
  handleSubmit3 = e => {
    this.setState({ error: "" });
    this.setState({ avatarURL: "" });
    this.setState({ title: "" });
    this.setState({ desc: "" });
    this.setState({ size: "" });
    this.setState({ activityCode: "" });
    this.setState({ address: "" });
    this.setState({ startDate: "" });
    this.setState({ endDate: "" });
    this.setState({ pdf: "" });
    this.setState({ hours: 0 });
    this.props.clearActivity(this.state);
  };
  handleChangeUsername = event =>
    this.setState({ username: event.target.value });
  handleUploadStart = () => this.setState({ isUploading: true, progress: 0 });
  handleProgress = progress => this.setState({ progress });
  handleUploadError = error => {
    this.setState({ isUploading: false });
  };
  handleUploadSuccess = filename => {
    this.setState({ avatar: filename, progress: 100, isUploading: false });
    firebase
      .storage()
      .ref("images")
      .child(filename)
      .getDownloadURL()
      .then(url => this.setState({ avatarURL: url }));
  };
  handleChangeUsernamePDF = event =>
    this.setState({ username: event.target.value });
  handleUploadStartPDF = () =>
    this.setState({ isUploading: true, progress: 0 });
  handleProgressPDF = progress => this.setState({ progress });
  handleUploadErroPDF = error => {
    this.setState({ isUploading: false });
  };
  handleUploadSuccessPDF = filename => {
    this.setState({ avatarPDF: filename, progress: 100, isUploading: false });
    firebase
      .storage()
      .ref("images")
      .child(filename)
      .getDownloadURL()
      .then(url => this.setState({ pdf: url }));
  };
  handleDateChange = date => {
    console.log(date);
    this.setState({ startDate: date });
  };

  handleDateChangeEnd = date => {
    console.log(date);
    this.setState({ endDate: date });
  };
  render() {
    const { profile } = this.props;
    const { assignError } = this.props;
    const { deleateError } = this.props;
    const { activityError } = this.props;
    let action;
    if (profile.type == "Hours") {
      action = (
        <form>
          <div className="aInfor">Hours / Attendance</div>
          <input
            type="number"
            placeholder="Hours Gained"
            className="abHours"
            value={this.state.hours}
            onChange={this.handleChange}
            name="hours"
          />
        </form>
      );
    }
    if (activityError == "Activity Sucessfully Created") {
      NotificationManager.success("Success", "Activity Sucessfully Created");
      {
        this.handleSubmit3();
      }
      {
        this.closeModal();
      }
    }
    if (assignError == "Student Assigned. You can close the pop up now") {
      NotificationManager.success("Success", "Student Sucessfully Assigned");
      {
        this.handleSubmit5();
      }
      {
        this.closeModal2();
      }
    }
    if (deleateError == "User admin deleted. You can close the pop up now. ") {
      NotificationManager.success("Success", "Student Sucessfully Deleted");
      {
        this.handleSubmit6();
      }
      {
        this.closeModal3();
      }
    }
    return (
      <div>
        <NotificationContainer />
        <div className="topbarmenu">
          <img src={menuBar} className="background" alt="logo" />
          <div className="home1">
            Home
            <div className="logoutButton">
              <DropDownMenu
                getItems={this.getDynamicItems}
                onClick={this.logout}
                direction={DropDownDirection.DownRight}
              />
              <img src={triangle} alt="logo" />
            </div>
          </div>

          <div className="rectangle2"></div>
          <div className="rectangle3"></div>
          <div className="user">Hi, {profile.name}</div>

          <Router>
            <div className="activities1">
              <NavLink
                exact
                to="/published"
                className="mainNav3"
                activeClassName="mainNavActive1"
              >
                {" "}
                Published
              </NavLink>
              <NavLink
                to="/published/requests"
                className="mainNav"
                activeClassName="mainNavActive2"
              >
                Requests
              </NavLink>
              <NavLink
                to="/published/assigned"
                className="mainNav2"
                activeClassName="mainNavActive3"
              >
                Assigned
              </NavLink>
            </div>
            {homeMaestroRoutes.map(route => (
              <Route
                key={route.path}
                path={route.path}
                exact={route.exact}
                component={route.main}
              />
            ))}
          </Router>
        </div>
        <button className="uiwebappcreatenewactivity" onClick={this.openModal}>
          <div className="rectangle21">
            <div className="group">
              <div className="createanewactivit"> + Create a new activity</div>
            </div>
          </div>
        </button>
        <Popup
          open={this.state.open}
          closeOnDocumentClick
          onClose={this.closeModal}
        >
          <div className="modal">
            <a className="close" onClick={this.closeModal}>
              &times;
            </a>
            <div className="actividadespublicadascopy7">
              <div className="cActivityTitle">Create a New Activity</div>

              <div className="catchError">{activityError}</div>
              <div className="aImage">Image</div>
              <form>
                {this.state.isUploading && (
                  <p>Progress: {this.state.progress}</p>
                )}
                <FileUploader
                  accept="image/*"
                  className="abImage"
                  name="avatar"
                  randomizeFilename
                  maxHeight="350"
                  storageRef={firebase.storage().ref("images")}
                  onUploadStart={this.handleUploadStart}
                  onUploadError={this.handleUploadError}
                  onUploadSuccess={this.handleUploadSuccess}
                  onProgress={this.handleProgress}
                />

                <div className="aTitle">Activity Title</div>

                <input
                  type="text"
                  placeholder="Title "
                  className="abTitle"
                  value={this.state.title}
                  onChange={this.handleChange}
                  name="title"
                  required
                />
                <div className="aDesc">Description</div>
                <textarea
                  name="desc"
                  placeholder="Please write a description of the activity, including start time and end time and any other helpful information"
                  className="abDesc"
                  onChange={this.handleChange}
                  value={this.state.desc}
                />
                <div className="aSize"># of Volunteers</div>
                <input
                  type="number"
                  placeholder="Size "
                  className="abSize"
                  value={this.state.size}
                  onChange={this.handleChange}
                  name="size"
                />
                <div className="aID">Frequency</div>
                <select
                  name="frequency"
                  placeholder="Select Frequency"
                  className="abID"
                  onChange={this.handleChange}
                >
                  <option value="Weekly">Weekly</option>
                  <option value="One Time">One Time</option>
                </select>

                <div className="aMentor">Address</div>

                <input
                  type="text"
                  placeholder="Address"
                  className="abMentor"
                  value={this.state.address}
                  onChange={this.handleChange}
                  name="address"
                />
                <div className="aDate">Start Date</div>
                <div className="dateHelper">
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDatePicker
                      disableToolbar
                      variant="inline"
                      format="MM/dd/yyyy"
                      margin="normal"
                      name="startDate"
                      label=""
                      value={this.state.startDate}
                      onChange={this.handleDateChange}
                      KeyboardButtonProps={{
                        "aria-label": "change date"
                      }}
                    />
                  </MuiPickersUtilsProvider>
                </div>
                <div className="aDate2">End Date</div>
                <div className="dateHelper2">
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDatePicker
                      disableToolbar
                      variant="inline"
                      format="MM/dd/yyyy"
                      margin="normal"
                      name="endDate"
                      label=""
                      value={this.state.endDate}
                      onChange={this.handleDateChangeEnd}
                      KeyboardButtonProps={{
                        "aria-label": "change date"
                      }}
                    />
                  </MuiPickersUtilsProvider>
                </div>
                <div className="aTime">Activity ID#</div>
                <input
                  type="text"
                  placeholder="Activity ID# "
                  className="abTime"
                  value={this.state.activityCode}
                  onChange={this.handleChange}
                  name="activityCode"
                />
              </form>

              {action}

              <button className="bCreateA" onClick={this.handleSubmit}>
                <div className="createActivityWhite"> Create Activity </div>
              </button>
            </div>
          </div>
        </Popup>
        <button
          className="uiwebappcreatenewactivity2"
          onClick={this.openModal2}
        >
          <div className="rectangle212">
            <div className="group2">
              <div className="createanewactivit2">+ Assign Activity</div>
            </div>
          </div>
        </button>
        <Popup
          open={this.state.open2}
          closeOnDocumentClick
          onClose={this.closeModal2}
        >
          {close => (
            <div className="modal">
              <a className="close" onClick={close}>
                &times;
              </a>
              <div className="actividadespublicadascopy72">
                <div className="catchError">{assignError}</div>
                <div className="assignTitle">Assign Activity</div>
                <div className="assignStudent">Student</div>
                <form>
                  <input
                    type="email"
                    placeholder="Please enter his/her email "
                    className="aabName"
                    value={this.state.student}
                    onChange={this.handleChange}
                    name="student"
                  />
                </form>
                <div className="assignActivity">Activity</div>
                <form>
                  <input
                    type="text"
                    placeholder="Please enter the activity's ID#"
                    className="aabActivity"
                    value={this.state.activity}
                    onChange={this.handleChange}
                    name="activity"
                  />
                </form>
                <button className="assignButton" onClick={this.handleSubmit2}>
                  Assign
                </button>
              </div>
            </div>
          )}
        </Popup>
        <button
          className="uiwebappcreatenewactivity3"
          onClick={this.openModal3}
        >
          <div className="rectangle213">
            <div className="group3">
              <div className="createanewactivit3">- Delete User Admin</div>
            </div>
          </div>
        </button>
        <Popup
          open={this.state.open3}
          closeOnDocumentClick
          onClose={this.closeModal3}
        >
          {close => (
            <div className="modal">
              <a className="close" onClick={close}>
                &times;
              </a>
              <div className="actividadespublicadascopy72">
                <div className="catchError">{deleateError}</div>
                <div className="assignTitle">Delete User Admin</div>
                <div className="assignStudent">Student</div>
                <form>
                  <input
                    type="text"
                    placeholder="Please enter his/her email "
                    className="aabName"
                    value={this.state.student}
                    onChange={this.handleChange}
                    name="student"
                  />
                </form>
                <div className="assignActivity">Activity</div>
                <form>
                  <input
                    type="text"
                    placeholder="Please enter the activity's ID#"
                    className="aabActivity"
                    value={this.state.activity}
                    onChange={this.handleChange}
                    name="activity"
                  />
                </form>
                <button className="assignButton" onClick={this.handleSubmit4}>
                  Delete
                </button>
              </div>
            </div>
          )}
        </Popup>
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    profile: state.firebase.profile,
    assignError: state.activitys.assignError,
    deleateError: state.activitys.deleateError,
    activityError: state.activitys.activityError
  };
}
const mapDispatchToProps = dispatch => {
  return {
    createActivity: activity => dispatch(createActivity(activity)),
    assignActivity: admin => dispatch(assignActivity(admin)),
    clearActivity: activity => dispatch(clearActivity(activity)),
    deleateUserAdmin: activity => dispatch(deleateUserAdmin(activity)),
    clearDelete: activity => dispatch(clearDelete(activity)),
    clearAssign: activity => dispatch(clearAssign(activity))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreenMaestro);
