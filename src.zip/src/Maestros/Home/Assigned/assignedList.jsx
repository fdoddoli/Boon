import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import AssignedDetaile from "./assignedDetaile";
import Loader from "react-loader-spinner";

class AssignedList extends Component {
  render() {
    const { usuarios } = this.props;
    const { profile } = this.props;
    if (usuarios != null) {
      return (
        <div className="pprruueebbaa2">
          <ul className="ulllll2">
            {usuarios &&
              usuarios.map(usuario => {
                if (usuario.school == profile.schoolCode) {
                  return <AssignedDetaile usuario={usuario} />;
                }
              })}
          </ul>
        </div>
      );
    } else {
      return (
        <div className="spinner">
          <Loader
            type="TailSpin"
            color="rgba(231, 91, 16, 1.0)"
            height={150}
            width={150}
          />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    usuarios: state.firestore.ordered.UsersAdmin,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "UsersAdmin" }])
)(AssignedList);
