import React from "react";
import "../../../HomeTest.css";
import daniel from "../../../img/daniel.jpg";

const AssignedDetaile = ({ usuario }) => {
  let action;
  if (usuario.avatarURLP) {
    action = usuario.avatarURLP;
  } else {
    action = daniel;
  }
  return (
    <li className="studentContainer">
      <div className="a">
        <img src={action} className="assignedFoto" alt="logo" />
        <div className="assignedName">{usuario.student}</div>
        <div className="assignedEmail">{usuario.email}</div>
        <div className="assignedID">Activity #{usuario.activity}</div>
      </div>
    </li>
  );
};

export default AssignedDetaile;
