import React, { Component } from "react";
import menuBar from "../../img/menuBar.png";
import "../../HomeTest.css";
import inputRectangle from "../../img/inputRectangle.png";
import triangle from "../../img/triangleDropDown.png";
import { connect } from "react-redux";
import firebase from "firebase";
import {
  ActionItem,
  DropDownMenu,
  DropDownDirection
} from "react-dropdown-advanced";

class SettingsMaestro extends Component {
  logout = () => {
    firebase.auth().signOut();
  };
  getDynamicItems = () => {
    var arr: DropDownItemBase[] = [];
    arr.push(new ActionItem("logout", "Logout", ""));

    return arr;
  };
  render() {
    const { profile } = this.props;
    return (
      <div className="topbarmenu">
        <img src={menuBar} className="background" alt="logo" />
        <div className="home1">
          Information
          <div className="logoutButton">
            <DropDownMenu
              getItems={this.getDynamicItems}
              onClick={this.logout}
              direction={DropDownDirection.DownRight}
            />

            <img src={triangle} alt="logo" />
          </div>
        </div>
        <div className="uiwebappcreatenewactivity">
          <div className="background1"></div>
        </div>
        <div className="activities1">Information</div>
        <div className="rectangle2"></div>
        <div className="rectangle3"></div>

        <div className="user">Hi, {profile.name}</div>
        <div className="uiwebappgeneralsettings">
          <div className="background"></div>
          <div className="nombre">Name</div>
          <img src={inputRectangle} className="rectangle4" alt="logo" />
          <div className="americanschoolfoun">{profile.name}</div>
        </div>
        <div className="uiwebappgeneralsettingscopy4">
          <div className="background"></div>
          <div className="nombre">Email</div>
          <img src={inputRectangle} className="rectangle4" alt="logo" />
          <div className="americanschoolfoun">{profile.email}</div>
        </div>
        <div className="uiwebappgeneralsettingscopy2copy">
          <div className="background"></div>
          <div className="nombre">School Code</div>
          <img src={inputRectangle} className="rectangle4" alt="logo" />
          <div className="americanschoolfoun">{profile.schoolCode}</div>
        </div>
        <div className="uiwebappgeneralsettingscopy3copy">
          <div className="background"></div>
          <div className="nombre">Password</div>
          <img src={inputRectangle} className="rectangle4" alt="logo" />
          <div className="americanschoolfoun">*******</div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};

export default connect(mapStateToProps)(SettingsMaestro);
