import React, { Component } from "react";
import "../App.css";
import { connect } from "react-redux";
import { signUpMaestro } from "../Actions/authActions";
class SignUPMaestro extends Component {
  state = {
    name: "",
    email: "",
    studentID: "",
    schoolCode: "",
    avatarURL: "",
    rol: "maestro",
    password: "",
    cPassword: "",
    fireErrors: "",
    acumulated: "0",
    horas: 0,
    asistencias: 0
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.signUpMaestro(this.state);
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    const { authError } = this.props;
    let errorNotification = this.state.fireErrors ? (
      <div className="signUpError"> {this.state.fireErrors}</div>
    ) : null;
    return (
      <div className="actividadespublicadascopy7">
        <div className="step1of1">{authError}</div>
        <div className="createUser">Add a Teacher</div>
        <button className="buttonSignUp" onClick={this.handleSubmit}>
          Sign Up
        </button>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="NameSignUP"
            onChange={this.handleChange}
            value={this.state.name}
            name="name"
          />
        </form>

        <form>
          <input
            type="text"
            placeholder="Email "
            className="EmailSignUP"
            value={this.state.email}
            onChange={this.handleChange}
            name="email"
          />
        </form>

        <form>
          <input
            type="text"
            placeholder="School Code "
            className="SchoolSignUP"
            value={this.state.schoolCode}
            onChange={this.handleChange}
            name="schoolCode"
          />
        </form>
        <form>
          <input
            type="text"
            placeholder="Password (More than 6 characters) "
            className="PasswordSignUP"
            value={this.state.password}
            onChange={this.handleChange}
            name="password"
          />
        </form>
        <form>
          <input
            type="text"
            placeholder="Confirm Password "
            className="CPasswordSignUP"
            value={this.state.cPassword}
            onChange={this.handleChange}
            name="cPassword"
          />
        </form>
        {errorNotification}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    authError: state.auth.authError
  };
};

const mapDispatchToProps = dispatch => {
  return {
    signUpMaestro: newUser => dispatch(signUpMaestro(newUser))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(SignUPMaestro);
