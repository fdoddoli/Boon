export const signUp = newUser => {
  return (dispatch, getState, getFirebase) => {
    const firebase = getFirebase();
    const db = firebase.firestore();
    let { info } = db;
    db.collection("Escuelas")
      .where("schoolCode", "==", newUser.schoolCode)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          dispatch({ type: "SCHOOL_DOES_NOT_EXIST", newUser });
          return;
        }
        snapshot.forEach(doc => {
          info = doc.data();
          firebase
            .auth()
            .createUserWithEmailAndPassword(newUser.email, newUser.password)
            .then(resp => {
              return db
                .collection("Usuarios")
                .doc(resp.user.uid)
                .set({
                  name: newUser.name,
                  studentBoonID: resp.user.uid,
                  email: newUser.email,
                  asistencias: newUser.asistencias,
                  horas: newUser.horas,
                  avatarURL: newUser.avatarURL,
                  type: info.type,
                  studentID: newUser.studentID,
                  schoolCode: newUser.schoolCode,
                  school: info.name
                });
            })
            .then(() => {
              dispatch({ type: "SIGNUP_SUCCESS" });
            })
            .catch(err => {
              dispatch({ type: "SIGNUP_ERROR", err });
              console.log(err);
            });
        });
      })
      .catch(err => {
        dispatch({ type: "SIGNUP_ERROR", err });
      });
  };
};
export const signUpMaestro = newUser => {
  return (dispatch, getState, getFirebase) => {
    const firebase = getFirebase();
    const db = firebase.firestore();
    let { info } = db;
    db.collection("Escuelas")
      .where("schoolCode", "==", newUser.schoolCode)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          dispatch({ type: "SCHOOL_DOES_NOT_EXIST", newUser });
          return;
        }
        snapshot.forEach(doc => {
          info = doc.data();
          firebase
            .auth()
            .createUserWithEmailAndPassword(newUser.email, newUser.password)
            .then(resp => {
              return db
                .collection("Usuarios")
                .doc(resp.user.uid)
                .set({
                  name: newUser.name,
                  studentBoonID: resp.user.uid,
                  email: newUser.email,
                  asistencias: newUser.asistencias,
                  horas: newUser.horas,
                  rol: newUser.rol,
                  avatarURL: newUser.avatarURL,
                  type: info.type,
                  studentID: newUser.studentID,
                  schoolCode: newUser.schoolCode,
                  school: info.name
                });
            })
            .then(() => {
              dispatch({ type: "SIGNUP_SUCCESS" });
            })
            .catch(err => {
              dispatch({ type: "SIGNUP_ERROR", err });
            });
        });
      })
      .catch(err => {
        dispatch({ type: "SIGNUP_ERROR", err });
      });
  };
};

export const forgotPassword = email => {
  return (dispatch, getState, getFirebase) => {
    const firebase = getFirebase();
    firebase
      .auth()
      .sendPasswordResetEmail(email)
      .then(() => {
        dispatch({ type: "FORGOT_PASSWORD_SENT" });
      })
      .catch(err => {
        dispatch({ type: "FORGOT_PASSWORD_ERR", err });
      });
  };
};
