export const createActivity = activity => {
  return (dispatch, getState, getFirebase) => {
    const profile = getState().firebase.profile;
    const firebase = getFirebase();
    const db = firebase.firestore();
    if (activity.startDate > activity.endDate) {
      dispatch({ type: "CREATE_ACTIVITY_DATE_ERROR", activity });
      return;
    }
    if (activity.address === "") {
      dispatch({ type: "CREATE_ACTIVITY_ADDRESS_EMPTY", activity });
      return;
    }
    var dd = String(activity.startDate.getDate()).padStart(2, "0");
    var mm = String(activity.startDate.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = activity.startDate.getFullYear();
    let startDate = yyyy + "-" + mm + "-" + dd;
    dd = String(activity.endDate.getDate()).padStart(2, "0");
    mm = String(activity.endDate.getMonth() + 1).padStart(2, "0"); //January is 0!
    yyyy = activity.endDate.getFullYear();
    let endDate = yyyy + "-" + mm + "-" + dd;
    db.collection("Actividades")
      .where("activityCode", "==", activity.activityCode)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          db.collection("Actividades")
            .add({
              activityCode: activity.activityCode,
              address: activity.address,
              avatarURL: activity.avatarURL,
              currentSignUps: activity.currentSignUps,
              desc: activity.desc,
              endDate: endDate,
              hours: activity.hours,
              frequency: activity.frequency,
              pdf: activity.pdf,
              status: activity.status,
              size: activity.size,
              startDate: startDate,
              title: activity.title,
              school: profile.schoolCode,
              createdby: profile.name,
              createdDate: new Date()
            })
            .then(() => {
              dispatch({ type: "CREATE_ACTIVITY", activity });
            })
            .catch(err => {
              dispatch({ type: "CREATE_ACTIVITY_ERROR", err });
            });
          return;
        }
        snapshot.forEach(doc => {
          dispatch({ type: "CREATE_ACTIVITY_ERROR_ID_EXISTS", activity });
        });
      });
  };
};
export const clearActivity = activity => {
  return (dispatch, getState, { getFirebase, getFirestore }) => {
    dispatch({ type: "CREATE_ACTIVITY_RESET", activity });
  };
};

export const clearAssign = activity => {
  return (dispatch, getState, { getFirebase, getFirestore }) => {
    dispatch({ type: "ASSIGN_ACTIVITY_RESET", activity });
  };
};

export const clearDelete = activity => {
  return (dispatch, getState, { getFirebase, getFirestore }) => {
    dispatch({ type: "DELETE_ASSIGN_ACTIVITY_RESET", activity });
  };
};
export const clearSignUp = activity => {
  return (dispatch, getState, { getFirebase, getFirestore }) => {
    dispatch({ type: "CLEAR_SIGNUP", activity });
  };
};
export const clearPublished = activity => {
  return (dispatch, getState, { getFirebase, getFirestore }) => {
    dispatch({ type: "CLEAR_PUBLISHED", activity });
  };
};
export const assignActivity = admin => {
  return (dispatch, getState, getFirebase) => {
    const firebase = getFirebase();
    const db = firebase.firestore();
    const profile = getState().firebase.profile;
    let { activityyy } = firebase;
    let { activityyy2 } = firebase;
    db.collection("Actividades")
      .where("activityCode", "==", admin.activity)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          dispatch({ type: "ASSIGN_ACTIVITY_ERROR_NO_ACTIVITY", admin });
          return;
        }
        snapshot.forEach(doc => {
          activityyy = doc.data();
          db.collection("Usuarios")
            .where("email", "==", admin.student)
            .get()
            .then(snapshot2 => {
              if (snapshot2.empty) {
                dispatch({ type: "ASSIGN_ACTIVITY_ERROR_NO_STUDENT", admin });
                return;
              }
              snapshot2.forEach(doc => {
                activityyy2 = doc.data();
                db.collection("UsersAdmin")
                  .add({
                    activity: admin.activity,
                    address: activityyy.address,
                    avatarURL: activityyy2.avatarURL,
                    desc: activityyy.desc,
                    student: admin.student,
                    hours: activityyy.hours,
                    startDate: activityyy.startDate,
                    title: activityyy.title,
                    avatarURLP: activityyy.avatarURL,
                    endDate: activityyy.endDate,
                    school: profile.schoolCode,
                    teacher: profile.name,
                    createdDate: new Date()
                  })
                  .then(() => {
                    db.collection("Notifications").add({
                      code: admin.activity,
                      user: admin.student,
                      type: "A",
                      createdDate: new Date()
                    });
                    dispatch({ type: "ASSIGN_ACTIVITY", admin });
                  })
                  .catch(err => {
                    dispatch({ type: "ASSIGN_ACTIVITY_ERROR", err });
                  });
              });
            })
            .catch(err => {
              dispatch({ type: "ASSIGN_ACTIVITY_ERROR", err });
            });
        });
      });
  };
};
export const registerSchool = school => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    const profile = getState().firebase.profile;
    db.collection("Escuelas")
      .add({
        ...school,
        createdDate: new Date()
      })
      .then(() => {
        dispatch({ type: "CREATE_ACTIVITY", school });
      })
      .catch(err => {
        dispatch({ type: "CREATE_ACTIVITY_ERROR", err });
      });
  };
};

export const signUpActivity = (activity, id) => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    //console.log(activity.id);
    const profile = getState().firebase.profile;
    db.collection("ActividadesyUsuarios")
      .where("studentID", "==", profile.studentID)
      .where("activityCode", "==", activity.activityCode)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          db.collection("Actividades")
            .doc(id)
            .update({ currentSignUps: activity.currentSignUps + 1 });
          db.collection("ActividadesyUsuarios")
            .add({
              ...activity,
              activityCode: activity.activityCode,
              address: activity.address,
              avatarURL: activity.avatarURL,
              currentSignUps: activity.currentSignUps,
              desc: activity.desc,
              endDate: activity.endDate,
              startDate: activity.startDate,
              status: activity.status,
              frequency: activity.frequency,
              title: activity.title,
              activityID: id,
              school: profile.schoolCode,
              studentName: profile.name,
              studentBoonID: profile.studentBoonID,
              avatarURLP: profile.avatarURL,
              horas: profile.horas,
              type: profile.type,
              asistencias: profile.asistencias,
              studentEmail: profile.email,
              studentID: profile.studentID,
              createdDate: new Date()
            })
            .then(() => {
              dispatch({ type: "SIGN_UP_SUCCESS", activity });
            })
            .catch(err => {
              dispatch({ type: "CREATE_ACTIVITY_ERROR", err });
            });
        }
      })
      .catch(err => {
        console.log("Error getting documents", err);
      });
  };
};

export const rolCallActivity = (activity, estudiante) => {
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  var yyyy = today.getFullYear();
  today = mm + "/" + dd + "/" + yyyy;
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    const profile = getState().firebase.profile;
    if (activity.type == "Hours") {
      db.collection("Usuarios")
        .doc(activity.studentBoonID)
        .update({ horas: parseInt(activity.hours) + parseInt(activity.horas) })
        .then(() => {
          db.collection("ActividadesyUsuarios")
            .doc(activity.id)
            .update({
              horas: parseInt(activity.hours) + parseInt(activity.horas)
            });
        });
    } else {
      db.collection("Usuarios")
        .doc(activity.studentBoonID)
        .update({ asistencias: parseInt(activity.asistencias) + 1 })
        .then(() => {
          db.collection("ActividadesyUsuarios")
            .doc(activity.id)
            .update({ asistencias: parseInt(activity.asistencias) + 1 });
        });
    }
    db.collection("Asistencia")
      .add({
        grade: estudiante.grade,
        gradeDesc: estudiante.gradeDesc,
        studentUID: activity.studentBoonID,
        title: activity.title,
        activityCode: activity.activityCode,
        studentName: activity.studentName,
        studentEmail: activity.studentEmail,
        studentID: activity.studentID,
        hours: activity.hours,
        schoolID: profile.schoolCode,
        gradedBy: profile.name,
        gradedDate: today
      })
      .then(() => {
        dispatch({ type: "ROLL_CALL_SUSCESS", activity });
      })
      .catch(err => {
        dispatch({ type: "ROLL_CALL_ERROR", err });
      });
  };
};

export const publishActivity = activity => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    const profile = getState().firebase.profile;
    db.collection("Actividades")
      .doc(activity.id)
      .update({ status: "Autorizado", createdby: profile.name })
      .then(() => {
        dispatch({ type: "PUBLISH_SUSCESS", activity });
      })
      .catch(err => {
        dispatch({ type: "PUBLISH_ERROR", err });
      });
  };
};

export const deleateActivity = activity => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    let activityInfo;
    const firebase = getFirebase();
    const db = firebase.firestore();
    db.collection("Actividades")
      .doc(activity.id)
      .delete()
      .then(() => {
        dispatch({ type: "DELEATE_SUSCESS", activity });
      });
    db.collection("ActividadesyUsuarios")
      .where("activityID", "==", activity.id)
      .get()
      .then(snapshot => {
        snapshot.forEach(doc => {
          activityInfo = doc.data();
          db.collection("ActividadesyUsuarios")
            .doc(doc.id)
            .delete();
          db.collection("Notifications").add({
            code: activityInfo.activityCode,
            user: activityInfo.studentEmail,
            type: "D",
            createdDate: new Date()
          });
        });
      })
      .catch(err => {});
  };
};

export const changeProfilePic = user => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    const authID = getState().firebase.auth.uid;
    db.collection("Usuarios")
      .doc(authID)
      .update({ avatarURL: user.avatarURL });
  };
};

export const deleateUserAdmin = admin => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    const profile = getState().firebase.profile;
    let { activityyy } = firebase;
    db.collection("UsersAdmin")
      .where("activity", "==", admin.activity)
      .where("student", "==", admin.student)
      .get()
      .then(snapshot => {
        if (snapshot.empty) {
          dispatch({ type: "ASSIGN_DELETE_ERROR_NO_ACTIVITY", admin });
          return;
        }
        snapshot.forEach(doc => {
          activityyy = doc.data();
          db.collection("UsersAdmin")
            .doc(doc.id)
            .delete()
            .then(() => {
              dispatch({ type: "ASSIGN_DELETE_SUCCESS", admin });
            })
            .catch(err => {});
        });
      });
  };
};
export const updateAsistanceTable = (newData, oldData) => {
  return (dispatch, getState, getFirebase) => {
    //asynx call to database
    const firebase = getFirebase();
    const db = firebase.firestore();
    const profile = getState().firebase.profile;

    db.collection("Asistencia")
      .doc(newData.id)
      .update({
        gradeDesc: newData.gradeDesc,
        hours: newData.hours,
        grade: newData.grade
      });
    if (oldData.hours != newData.hours) {
      let newHours = newData.hours - oldData.hours;
      let ref = db.collection("Usuarios").doc(newData.studentUID);
      ref
        .get()
        .then(doc => {
          let userDocument = doc.data();
          ref.update({
            horas: parseInt(userDocument.horas) + parseInt(newHours)
          });
        })
        .catch(err => {
          console.log("Error getting document", err);
        });
    }
    // .update({
    //   horas: ""
    // });
  };
};
