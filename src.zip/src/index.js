import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import firebase from "firebase";
import * as serviceWorker from "./serviceWorker";
import { Provider, useSelector } from "react-redux";
import {
  ReactReduxFirebaseProvider,
  getFirestore,
  getFirebase,
  isLoaded
} from "react-redux-firebase";
import { createStore, applyMiddleware, compose } from "redux";
import allReducer from "./Reducers/allReducer";
import thunk from "redux-thunk";
import { createFirestoreInstance } from "redux-firestore";

function AuthIsLoaded({ children }) {
  const auth = useSelector(state => state.firebase.auth);
  if (!isLoaded(auth)) return <div></div>;
  return children;
}

const firebaseConfig = {
  apiKey: "AIzaSyBSiFf5m00xRVLS4jFcpsPN3pn93Kn9ld4",
  authDomain: "boon-2c048.firebaseapp.com",
  databaseURL: "https://boon-2c048.firebaseio.com",
  projectId: "boon-2c048",
  storageBucket: "boon-2c048.appspot.com",
  messagingSenderId: "721610292649",
  appId: "1:721610292649:web:5de4277fb80cd8726018b8",
  measurementId: "G-KBT8NW4CKT"
};

const rrfConfig = {
  userProfile: "Usuarios",
  useFirestoreForProfile: true
};

const middlewares = [thunk.withExtraArgument(getFirebase, getFirestore)];

const store = createStore(allReducer, compose(applyMiddleware(...middlewares)));

firebase.initializeApp(firebaseConfig);
firebase.firestore();

const rrfProps = {
  firebase,
  config: rrfConfig,
  dispatch: store.dispatch,
  createFirestoreInstance
};

// const store = createStore(
//   allReducer,
//   compose(
//     applyMiddleware(thunk.withExtraArgument({ getFirebase, getFirestore })),
//     reduxFirestore(Fire),
//     reactReduxFirebase(Fire, {
//       attachAuthIsReady: true,
//       useFirestoreForProfile: true,
//       userProfile: "Usuarios"
//     })
//   )
// );
ReactDOM.render(
  <Provider store={store}>
    <ReactReduxFirebaseProvider {...rrfProps}>
      <AuthIsLoaded>
        <App />
      </AuthIsLoaded>
    </ReactReduxFirebaseProvider>
  </Provider>,
  document.getElementById("root")
);
serviceWorker.unregister();

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
