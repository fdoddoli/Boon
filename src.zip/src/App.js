import React, { Component } from "react";
import "./App.css";
import LoginRegister from "./Estudiantes/LoginRegister";
import HomeTest from "./Estudiantes/HomeTest";
import HomeTestMobile from "./Mobile/homeTestMobile";
import LoginRegisterMobile from "./Mobile/loginRegisterMobile";
import { isMobile } from "react-device-detect";
import { connect } from "react-redux";
import HomeTestMaestro from "./Maestros/homeTestMaestro";
import HomeTestAdmin from "./Admin/homeTestAdmin";
import firebase from "firebase";

class App extends Component {
  constructor() {
    super();
    this.state = {
      user: null
    };
  }

  componentDidMount() {
    this.authListener();
  }

  authListener() {
    firebase.auth().onAuthStateChanged(user => {
      if (user) {
        this.setState({ user });
      } else {
        this.setState({ user: null });
      }
    });
  }
  render() {
    const { profile } = this.props;

    if (isMobile) {
      return (
        <div>
          {this.state.user ? <HomeTestMobile /> : <LoginRegisterMobile />}
        </div>
      );
    } else if (profile.rol == null) {
      return <div>{this.state.user ? <HomeTest /> : <LoginRegister />}</div>;
    } else {
      return (
        <div>{this.state.user ? <HomeTestMaestro /> : <LoginRegister />}</div>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};

export default connect(mapStateToProps)(App);
