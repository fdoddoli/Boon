import React, { Component } from "react";
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import { NavLink } from "react-router-dom";
import topHeader from "../img/topHeader.png";
import siglium from "../img/sigliumDefault.png";
import "../HomeTest.css";
import homeImage from "../img/buttonHome.png";
import homeImageActive from "../img/homeButton.png";
import profileImage from "../img/Picture2.png";
import profileImageActive from "../img/Picture1.png";
import settingsImage from "../img/Picture3.png";
import settingsImageActive from "../img/Picture4.png";
import logoNombre from "../img/logoNombre.png";
import HomeScreenAdmin from "./homeScreenAdmin";

const routes = [
  {
    path: "/published",
    exact: true,
    main: HomeScreenAdmin
  }
];
class HomeTestAdmin extends Component {
  //The mainComponent sidebar and mainBackround
  constructor() {
    super();
    this.state = {
      homeUrl: homeImageActive,
      profileUrl: profileImage,
      settingsUrl: settingsImage
    };
    this.toggleIconHome = this.toggleIconHome.bind(this);
    this.toggleIconProfile = this.toggleIconProfile.bind(this);
    this.toggleIconSettings = this.toggleIconSettings.bind(this);
  }
  //function that changes sidebar selected image icon
  toggleIconHome() {
    this.setState({ homeUrl: homeImageActive });
    this.setState({ profileUrl: profileImage });
    this.setState({ settingsUrl: settingsImage });
  }
  toggleIconProfile() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImageActive });
    this.setState({ settingsUrl: settingsImage });
  }
  toggleIconSettings() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImage });
    this.setState({ settingsUrl: settingsImageActive });
  }

  //logout function firebase

  render() {
    return (
      <div className="mainScreen">
        <Router>
          <Redirect from="/" exact to="/published" />

          <div style={{ display: "flex" }}>
            <div
              style={{
                padding: "0%",
                height: "100%",
                width: "17%"
              }}
            >
              <div className="sideBar">
                <ul>
                  <div>
                    <img src={topHeader} className="topHeader" alt="logo" />
                    <img src={logoNombre} className="logoNombre" alt="logo" />
                    <img src={siglium} className="siglium" alt="logo" />{" "}
                    <div className="schoolName">ASFM</div>{" "}
                  </div>
                  <NavLink
                    to="/published"
                    activeClassName="sideBarImageActive"
                    className="sideBarImage"
                    onClick={this.toggleIconHome}
                  >
                    <div className="menu">
                      <div class="activemenuitem">
                        <div class="rectangle"></div>

                        <div className="menuitem1">
                          <div class="home2">Home</div>
                        </div>
                        <div class="home1">
                          <img
                            src={this.state.homeUrl}
                            className="shape"
                            alt="logo"
                          />
                        </div>
                      </div>
                    </div>
                  </NavLink>
                  <p></p>
                  <p></p>

                  <p></p>
                </ul>
              </div>
              {routes.map(route => (
                <Route
                  key={route.path}
                  path={route.path}
                  exact={route.exact}
                  component={route.main}
                />
              ))}
            </div>
          </div>
        </Router>
      </div>
    );
  }
}
export default HomeTestAdmin;
