import React, { Component } from "react";
import "../App.css";
import { connect } from "react-redux";
import { registerSchool } from "../Actions/activityActions";
class RegisterSchool extends Component {
  state = {
    name: "",
    email: "",
    type: "",
    schoolCode: ""
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.registerSchool(this.state);
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    let errorNotification = this.state.fireErrors ? (
      <div className="signUpError"> {this.state.fireErrors}</div>
    ) : null;
    return (
      <div className="actividadespublicadascopy7">
        <div className="step1of1"></div>
        <div className="createUser">Add School</div>
        <button className="buttonSignUp" onClick={this.handleSubmit}>
          Sign up
        </button>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="NameSignUP"
            onChange={this.handleChange}
            value={this.state.name}
            name="name"
          />
        </form>

        <form>
          <input
            type="text"
            placeholder="Email "
            className="EmailSignUP"
            value={this.state.email}
            onChange={this.handleChange}
            name="email"
          />
        </form>
        <form>
          <input
            type="text"
            placeholder="School Code "
            className="schoolCodeSignUP"
            value={this.state.schoolCode}
            onChange={this.handleChange}
            name="schoolCode"
          />
        </form>
        <div className="typeTitle">Type of Roll Call</div>
        <select
          className="abType"
          onChange={this.handleChange}
          value={this.state.type}
          name="type"
        >
          <option value="None"> </option>
          <option value="Hours">Hours</option>
          <option value="Asistence">Asistence</option>
        </select>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    auth: state.firebase.auth
  };
};

const mapDispatchToProps = dispatch => {
  return {
    registerSchool: newSchool => dispatch(registerSchool(newSchool))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(RegisterSchool);
