import React, { Component } from "react";
import menuBar from "../img/menuBar.png";
import { connect } from "react-redux";
import "../HomeTest.css";
import triangle from "../img/triangleDropDown.png";
import firebase from "firebase";
import {
  ActionItem,
  DropDownMenu,
  DropDownDirection
} from "react-dropdown-advanced";
import Popup from "reactjs-popup";
import { compose } from "redux";
import { createActivity } from "../Actions/activityActions";
import { firestoreConnect } from "react-redux-firebase";
import SignUp from "../Maestros/signUpMaestro";
import RegisterSchool from "./registerSchool";

class HomeScreenAdmin extends Component {
  state = {
    name: "",
    email: "",
    schoolCode: "",
    fireErrors: ""
  };
  logout = () => {
    firebase.auth().signOut();
  };
  getDynamicItems = () => {
    var arr: DropDownItemBase[] = [];
    arr.push(new ActionItem("logout", "Logout", ""));

    return arr;
  };
  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.createActivity(this.state);
  };
  handleSubmit2 = e => {
    e.preventDefault();
    this.props.assignActivity(this.state);
  };
  render() {
    const { profile } = this.props;
    return (
      <div>
        <div className="topbarmenu">
          <img src={menuBar} className="background" alt="logo" />
          <div className="home1">
            Home
            <div className="logoutButton">
              <DropDownMenu
                getItems={this.getDynamicItems}
                onClick={this.logout}
                direction={DropDownDirection.DownRight}
              />
              <img src={triangle} alt="logo" />
            </div>
          </div>

          <div className="rectangle2"></div>

          <div className="user">Hi, {profile.name}</div>
        </div>

        <Popup
          trigger={
            <button className="registerTeacher"> Register Teacher </button>
          }
          modal
        >
          {close => (
            <div className="modal">
              <a className="close" onClick={close}>
                &times;
              </a>
              <SignUp />
            </div>
          )}
        </Popup>

        <Popup
          trigger={
            <button className="registerSchool"> Register School </button>
          }
          modal
        >
          {close => (
            <div className="modal">
              <a className="close" onClick={close}>
                &times;
              </a>
              <RegisterSchool />
            </div>
          )}
        </Popup>
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    profile: state.firebase.profile
  };
}
const mapDispatchToProps = dispatch => {
  return {
    createActivity: activity => dispatch(createActivity(activity))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreenAdmin);
