import React, { Component } from "react";
import menuBar from "../../img/menuBar.png";
import toastr from "toastr";
import "../../HomeTest.css";
import {
  NotificationContainer,
  NotificationManager
} from "react-notifications";
import inputRectangle from "../../img/inputRectangle.png";
import triangle from "../../img/triangleDropDown.png";
import { connect } from "react-redux";
import firebase from "firebase";
import {
  ActionItem,
  DropDownMenu,
  DropDownDirection
} from "react-dropdown-advanced";
import Popup from "reactjs-popup";
import emailjs from "emailjs-com";

class SettingsScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      subject: "Error",
      problem: "",
      name: "Student",
      email: "",
      open: false
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }
  logout = () => {
    firebase.auth().signOut();
  };
  getDynamicItems = () => {
    var arr: DropDownItemBase[] = [];
    arr.push(new ActionItem("logout", "Logout", ""));

    return arr;
  };
  openModal() {
    this.setState({ open: true });
  }
  closeModal() {
    this.setState({ open: false });
  }
  handleChange = e => {
    this.setState({ problem: e.target.value });
  };

  handleSubmit = e => {
    e.preventDefault();
    if (this.state.problem !== "") {
      const templateId = "template_Zu5XW3qb";
      this.setState({ problem: "" });
      const templateParams = {
        from_name: this.state.name,
        to_name: "Boon",
        subject: this.state.subject,
        message_html: this.state.problem
      };
      emailjs
        .send(
          "boongmail",
          templateId,
          templateParams,
          "user_i1Wl9QEbsh3a04yKPqpAA"
        )
        .then(
          function(response) {
            NotificationManager.success(
              "Successfully Reported",
              "We will fix it ASAP"
            );
          },
          function(err) {
            toastr.error(err);
          }
        );
      this.setState({
        problem: "",
        open: false
      });
    }
  };

  render() {
    const { profile } = this.props;
    return (
      <div>
        <NotificationContainer />
        <Popup
          open={this.state.open}
          closeOnDocumentClick
          onClose={this.closeModal}
        >
          <div className="modal2">
            <div className="reportProblemModal">
              <div className="ReportText">Report a Problem</div>
              <textarea
                type="text"
                value={this.state.problem}
                className="ReportInput"
                placeholder="Please tell us what's wrong and we will fix it asap."
                onChange={this.handleChange}
                name="problem"
                required
              />
              <button className="bSendProblem" onClick={this.handleSubmit}>
                <div className="createActivityWhite"> Send </div>
              </button>
            </div>
          </div>
        </Popup>
        <div className="topbarmenu">
          <img src={menuBar} className="background" alt="logo" />
          <div className="home1">
            Information
            <div className="logoutButton">
              <DropDownMenu
                getItems={this.getDynamicItems}
                onClick={this.logout}
                direction={DropDownDirection.DownRight}
              />

              <img src={triangle} alt="logo" />
            </div>
          </div>
          <div className="uiwebappcreatenewactivity">
            <div className="background1"></div>
          </div>
          <div className="activities1">Information</div>
          <button className="Report" onClick={this.openModal}>
            Report Problem
          </button>
          <div className="rectangle2"></div>
          <div className="rectangle3"></div>
          <div className="user">Hi, {profile.name}</div>
          <div className="uiwebappgeneralsettings">
            <div className="background"></div>
            <div className="nombre">Name</div>
            <img src={inputRectangle} className="rectangle4" alt="logo" />
            <div className="americanschoolfoun">{profile.name}</div>
          </div>
          <div className="uiwebappgeneralsettingscopy4">
            <div className="background"></div>
            <div className="nombre">Email</div>
            <img src={inputRectangle} className="rectangle4" alt="logo" />
            <div className="americanschoolfoun">{profile.email}</div>
          </div>
          <div className="uiwebappgeneralsettingscopy">
            <div className="background"></div>
            <div className="nombre">School ID</div>
            <img src={inputRectangle} className="rectangle4" alt="logo" />
            <div className="americanschoolfoun">{profile.studentID}</div>
          </div>
          <div className="uiwebappgeneralsettingscopy2">
            <div className="background"></div>
            <div className="nombre">School Code</div>
            <img src={inputRectangle} className="rectangle4" alt="logo" />
            <div className="americanschoolfoun">{profile.schoolCode}</div>
          </div>
          <div className="uiwebappgeneralsettingscopy3">
            <div className="background"></div>
            <div className="nombre">Password</div>
            <img src={inputRectangle} className="rectangle4" alt="logo" />
            <div className="americanschoolfoun">*******</div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};

export default connect(mapStateToProps)(SettingsScreen);
