import React, { Component } from "react";
import boonMonkey from "../img/boonMonkey.png";
import "../App.css";
import firebase from "firebase";
import Popup from "reactjs-popup";
import SignUp from "./signUP";
import ForgotPassword from "./forgotPassword";
class LoginRegister extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      rol: "",
      fireErrors: ""
    };
  }

  login = e => {
    e.preventDefault();
    firebase
      .auth()
      .signInWithEmailAndPassword(this.state.email, this.state.password)
      .catch(error => {
        this.setState({ fireErrors: error.message });
      });
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    let errorNotification = this.state.fireErrors ? (
      <div className="Error"> {this.state.fireErrors}</div>
    ) : null;

    return (
      <div>
        <div className="actividadespublicadascopy6">
          <div
            style={{
              width: "100%",
              height: "100%",
              position: "relative",
              margin: "auto"
            }}
          >
            <div className="logoiconnormal">
              <div className="mask"></div>
              <div className="logoiconnormal2">
                <img src={boonMonkey} className="logo" alt="logo" />
              </div>
            </div>
            <div className="input">
              <div className="rectangle2"></div>
            </div>
            <div className="input1">
              <div className="rectangle2"></div>
            </div>
            <form>
              <input
                type="text"
                className="usernameBox"
                placeholder="Email"
                value={this.state.email}
                onChange={this.handleChange}
                name="email"
              />
              <input
                type="password"
                className="passwordBox"
                placeholder="Password "
                value={this.state.password}
                onChange={this.handleChange}
                name="password"
              />
              <button className="rectangle14" onClick={this.login}>
                <div className="signin">Log in</div>
              </button>
            </form>
            <div className="errorMessage">{errorNotification}</div>
            <div className="logoiconnormal1">
              <img src={boonMonkey} className="logo" alt="logo" />
            </div>
            {/* <div className="thenewstandardin">
              The new standard in <br />
              community service
            </div> */}
            <div className="thenewstandardin">
              Helping Students <br />
              Become Leaders
            </div>
            <div className="joinboontoday">Join Boon Today.</div>

            <Popup
              trigger={
                <button className="rectangle15">
                  <div className="signUpColor"> Sign up </div>{" "}
                </button>
              }
              modal
            >
              {close => (
                <div className="modal">
                  <a className="close" onClick={close}>
                    &times;
                  </a>
                  <SignUp />
                </div>
              )}
            </Popup>
            <button className="rectangle15copy" onClick={this.login}>
              <div className="signin1">Log in</div>
            </button>
            <Popup
              trigger={
                <button className="ForgotPasswordButton">
                  Forgot Password?
                </button>
              }
              modal
            >
              {close => (
                <div className="modal">
                  <a className="close" onClick={close}>
                    &times;
                  </a>
                  <ForgotPassword />
                </div>
              )}
            </Popup>
          </div>
        </div>
      </div>
    );
  }
}

export default LoginRegister;
