import React, { Component } from "react";
import { connect } from "react-redux";
import "../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import ActivityDetaile from "./notificationDetaile";

class MActivityListUserAdmin extends Component {
  render() {
    let { notifications } = this.props;
    const { profile } = this.props;
    if (notifications !== undefined) {
      notifications = notifications.sort(
        (a, b) => b.createdDate.seconds - a.createdDate.seconds
      );
    }

    return (
      <div className="NotificationsList">
        <ul className="ulNotifications">
          {notifications &&
            notifications.map(notification => {
              if (notification.user === profile.email) {
                return (
                  <ActivityDetaile
                    activity={notification}
                    key={notification.id}
                  />
                );
              } else {
                return null;
              }
            })}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    notifications: state.firestore.ordered.Notifications,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "Notifications" }])
)(MActivityListUserAdmin);
