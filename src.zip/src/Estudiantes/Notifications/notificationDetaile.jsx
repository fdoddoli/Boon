import React from "react";
import "../../HomeTest.css";
import NotificationDeleate from "../../img/notificationDeleate.png";
import NotificationAttendace from "../../img/notificationAttendance.png";

const NotificationDetaile = ({ activity }) => {
  let action;
  let action2;
  if (activity.type === "D") {
    action = NotificationDeleate;
    action2 = (
      <div className="NotificationsText">
        <strong>Activity {activity.code} </strong>has been canceled
      </div>
    );
  } else if (activity.type === "A") {
    action = NotificationAttendace;
    action2 = (
      <div className="NotificationsText">
        Student Admin of <strong>Activity {activity.code} </strong>
      </div>
    );
  }
  return (
    <li className="listaActividadesNotifiaciones">
      <div className="containers">
        <img src={action} className="NotificationIconImage" alt="logo" />
        {action2}
        <div className="mRectangleNotifications"></div>
      </div>
    </li>
  );
};

export default NotificationDetaile;
