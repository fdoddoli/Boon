import React, { Component } from "react";
import "../App.css";
import { connect } from "react-redux";
import { forgotPassword } from "../Actions/authActions";
class ForgotPassword extends Component {
  state = {
    email: ""
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.forgotPassword(this.state.email);
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    const { fpasswordError } = this.props;

    let errorNotification = this.state.fireErrors ? (
      <div className="signUpError"> {this.state.fireErrors}</div>
    ) : null;
    return (
      <div className="actividadespublicadascopy7">
        <div className="step2of2">{fpasswordError}</div>
        <div className="ForgotPasswordTitle">Forgot Password?</div>
        <div className="ForgotPasswordText">
          Please type in your email. An email will be sent to you with the steps
          to reset your password.
        </div>
        <form>
          <input
            type="text"
            placeholder="Email"
            className="ForgotPasswordEmailBox"
            value={this.state.email}
            onChange={this.handleChange}
            name="email"
          />
        </form>
        <button className="SubmitButton" onClick={this.handleSubmit}>
          <div className="signUpColor"> Submit </div>
        </button>
        {errorNotification}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    fpasswordError: state.auth.fpasswordError
  };
};

const mapDispatchToProps = dispatch => {
  return {
    forgotPassword: email => dispatch(forgotPassword(email))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);
