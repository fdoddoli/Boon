import React, { Component } from "react";
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import { NavLink } from "react-router-dom";
import topHeader from "../img/topHeader.png";
import siglium from "../img/sigliumDefault.png";
import "../HomeTest.css";
import homeImage from "../img/buttonHome.png";
import homeImageActive from "../img/homeButton.png";
import profileImage from "../img/Picture2.png";
import profileImageActive from "../img/Picture1.png";
import settingsImage from "../img/Picture3.png";
import settingsImageActive from "../img/Picture4.png";
import logoNombre from "../img/logoNombre.png";
import HomeScreen from "./Home/homeScreen";
import ProfileScreen from "./Profile/profileScreen";
import SettingsScreen from "./Settings/settingsScreen";
import HomeTestMaestro from "../Maestros/homeTestMaestro";
import { connect } from "react-redux";
import HomeTestAdmin from "../Admin/homeTestAdmin";

const routes = [
  {
    path: "/home",
    exact: true,
    main: HomeScreen
  },
  {
    path: "/profile",
    exact: true,
    main: ProfileScreen
  },
  {
    path: "/settings",
    exact: true,
    main: SettingsScreen
  }
];
class HomeTest extends Component {
  //The mainComponent sidebar and mainBackround
  constructor() {
    super();
    this.state = {
      homeUrl: homeImageActive,
      profileUrl: profileImage,
      settingsUrl: settingsImage
    };
    this.toggleIconHome = this.toggleIconHome.bind(this);
    this.toggleIconProfile = this.toggleIconProfile.bind(this);
    this.toggleIconSettings = this.toggleIconSettings.bind(this);
  }
  //function that changes sidebar selected image icon
  toggleIconHome() {
    this.setState({ homeUrl: homeImageActive });
    this.setState({ profileUrl: profileImage });
    this.setState({ settingsUrl: settingsImage });
  }
  toggleIconProfile() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImageActive });
    this.setState({ settingsUrl: settingsImage });
  }
  toggleIconSettings() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImage });
    this.setState({ settingsUrl: settingsImageActive });
  }

  //logout function firebase

  render() {
    const { profile } = this.props;
    if (profile.rol == null) {
      return (
        <div className="mainScreen">
          <Router>
            <Redirect from="/" exact to="/home" />

            <div style={{ display: "flex" }}>
              <div
                style={{
                  padding: "0%",
                  height: "100%",
                  width: "17%"
                }}
              >
                <div className="sideBar">
                  <ul>
                    <div>
                      <img src={topHeader} className="topHeader" alt="logo" />
                      <img src={logoNombre} className="logoNombre" alt="logo" />
                      <img src={siglium} className="siglium" alt="logo" />{" "}
                      <div className="schoolName">{profile.school}</div>{" "}
                    </div>
                    <NavLink
                      to="/home"
                      activeClassName="sideBarImageActive"
                      className="sideBarImage"
                      onClick={this.toggleIconHome}
                    >
                      <div className="menu">
                        <div className="activemenuitem">
                          <div className="rectangle"></div>

                          <div className="menuitem1">
                            <div className="home2">Home</div>
                          </div>
                          <div className="home1">
                            <img
                              src={this.state.homeUrl}
                              className="shape"
                              alt="logo"
                            />
                          </div>
                        </div>
                      </div>
                    </NavLink>
                    <p></p>
                    <NavLink
                      to="/profile"
                      activeClassName="sideBarImage2Active"
                      className="sideBarImage2"
                      onClick={this.toggleIconProfile}
                    >
                      <div className="menu">
                        <div>
                          <div></div>

                          <div className="menuitem1">
                            <div className="home2">Profile</div>
                          </div>
                          <div className="home1">
                            <img
                              src={this.state.profileUrl}
                              className="shape"
                              alt="logo"
                            />
                          </div>
                        </div>
                      </div>
                    </NavLink>
                    <p></p>
                    <NavLink
                      to="/settings"
                      activeClassName="sideBarImage3Active"
                      className="sideBarImage3"
                      onClick={this.toggleIconSettings}
                    >
                      <div className="menu">
                        <div>
                          <div className="menuitem1">
                            <div className="home2">Information</div>
                          </div>
                          <div className="home1">
                            <img
                              src={this.state.settingsUrl}
                              className="shape"
                              alt="logo"
                            />
                          </div>
                        </div>
                      </div>
                    </NavLink>
                    <p></p>
                  </ul>
                </div>
                {routes.map(route => (
                  <Route
                    key={route.path}
                    path={route.path}
                    exact={route.exact}
                    component={route.main}
                  />
                ))}
              </div>
            </div>
          </Router>
        </div>
      );
    } else if (profile.rol == "maestro") {
      return (
        <div>
          <HomeTestMaestro />
        </div>
      );
    } else if (profile.rol == "admin") {
      return (
        <div>
          <HomeTestAdmin />
        </div>
      );
    }
  }
}
const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};
export default connect(mapStateToProps)(HomeTest);
