import React, { Component } from "react";
import "../../../HomeTest.css";
import DefaultActivityIcon from "../../../img/defaultActivityIcon.png";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import calendar from "../../../img/calendar.png";
import pinPoint from "../../../img/pinPoint.png";
import Frequency from "../../../img/frequency.png";
import { publishActivity } from "../../../Actions/activityActions";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class UpcomingActivityInfo extends Component {
  state = {
    id: this.props.match.params.id,
    school: ""
  };

  handleSubmit = e => {
    this.props.publishActivity(this.state);
  };
  render() {
    const { activity } = this.props;
    let action;
    let startDate = activity.startDate.substring(5, 7);
    let endDate = activity.endDate.substring(5, 7);
    let action3;
    let action2;

    if (activity) {
      if (activity.avatarURL === "") {
        var image = DefaultActivityIcon;
      } else {
        image = activity.avatarURL;
      }
      if (endDate == "01") {
        action3 = (
          <div className="endDateInfo">
            Jan-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "01") {
        action2 = (
          <div className="startDate">
            Jan-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "02") {
        action3 = (
          <div className="endDateInfo">
            Feb-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "02") {
        action2 = (
          <div className="startDate">
            Feb-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "03") {
        action3 = (
          <div className="endDateInfo">
            Mar-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "03") {
        action2 = (
          <div className="startDate">
            Mar-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "04") {
        action3 = (
          <div className="endDateInfo">
            Apr-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "04") {
        action2 = (
          <div className="startDate">
            Apr-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "05") {
        action3 = (
          <div className="endDateInfo">
            May-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "05") {
        action2 = (
          <div className="startDate">
            May-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "06") {
        action3 = (
          <div className="endDateInfo">
            Jun-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "06") {
        action2 = (
          <div className="startDateInfo">
            Jun-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "07") {
        action3 = (
          <div className="endDateInfo">
            Jul-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "07") {
        action2 = (
          <div className="startDate">
            Jul-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "08") {
        action3 = (
          <div className="endDateInfo">
            Aug-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "08") {
        action2 = (
          <div className="startDate">
            Aug-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "09") {
        action3 = (
          <div className="endDateInfo">
            Sep-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "09") {
        action2 = (
          <div className="startDate">
            Sep-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "10") {
        action3 = (
          <div className="endDateInfo">
            Oct-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "10") {
        action2 = (
          <div className="startDate">
            Oct-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "11") {
        action3 = (
          <div className="endDateInfo">
            Nov-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "11") {
        action2 = (
          <div className="startDate">
            Nov-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "12") {
        action3 = (
          <div className="endDateInfo">
            Dec-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "12") {
        action2 = (
          <div className="startDate">
            Dec-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      return (
        <div>
          <div className="whiteBackroundDetaileA"></div>
          <div className="titleDetaileA">
            {activity.title}
            {action}
          </div>
          <img src={image} className="dfotoDetaileA" alt="logo" />

          <div className="timeDetaileA">+ {activity.size} hrs</div>
          <div className="ddescDetaileA">{activity.desc}</div>
          <div className="dateDetaileA">
            {action2}
            {action3}
          </div>

          <img src={calendar} className="calendarDetaileA" alt="logo" />
          <img src={pinPoint} className="pinPointDetaileA" alt="logo" />
          <img src={Frequency} className="frequencyDetaileA" alt="logo" />
          <div className="frequencywordDetaileA">{activity.frequency}</div>
          <div className="adressDetaileA">{activity.address}</div>
        </div>
      );
    } else {
      return <div> </div>;
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  const id = ownProps.match.params.id;
  const activitys = state.firestore.data.ActividadesyUsuarios;
  const activity = activitys ? activitys[id] : null;

  return {
    activity: activity
  };
};
const mapDispatchToProps = dispatch => {
  return {
    publishActivity: activity => dispatch(publishActivity(activity))
  };
};
export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  firestoreConnect([{ collection: "ActividadesyUsuarios" }])
)(UpcomingActivityInfo);
