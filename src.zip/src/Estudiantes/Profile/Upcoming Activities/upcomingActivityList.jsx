import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "../../../activityDetaile";

class UpcomingActivityList extends Component {
  render() {
    const { activitys } = this.props;
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    today = yyyy + "-" + mm + "-" + dd;

    const { profile } = this.props;

    return (
      <div className="pprruueebbaa">
        <ul className="ulllll">
          {activitys &&
            activitys.map(activity => {
              if (
                activity.studentEmail == profile.email &&
                today < activity.endDate
              ) {
                return (
                  <Link to={"/home/upcomming/" + activity.id}>
                    <ActivityDetaile activity={activity} key={activity.id} />
                  </Link>
                );
              }
            })}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.ActividadesyUsuarios,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect(props => {
    if (props.profile.schoolCode == undefined) return [];
    else {
      return [
        {
          collection: "ActividadesyUsuarios",
          where: ["school", "==", props.profile.schoolCode]
        }
      ];
    }
  })
)(UpcomingActivityList);
