import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import Cropper from "react-cropper";
import daniel from "../../../img/daniel.jpg";
import firebase from "firebase";
import { changeProfilePic } from "../../../Actions/activityActions";
import Popup from "reactjs-popup";
import FileUploader from "react-firebase-file-uploader";
import "cropperjs/dist/cropper.css";

// const cropper = React.createRef(null);

class ProfileInfo extends Component {
  state = {
    avatar: "",
    username: "",
    // isUploading: false,
    // progress: 0,
    // avatarURL: "",
    // cropper: null
  };

  handleChangeUsername = event =>
    this.setState({ username: event.target.value });
  // handleUploadStart = () => this.setState({ isUploading: true, progress: 0 });
  // handleProgress = progress => this.setState({ progress });
  // handleUploadError = error => {
  //   this.setState({ isUploading: false });
  //   console.error(error);
  // };
  // handleSubmit = e => {
  //   e.preventDefault();
  //   // this.props.changeProfilePic(this.state);
  //   // this.setState({ avatarURL: "" });
  // };

  // handleUploadSuccess = filename => {
  //   this.setState({ avatar: filename, progress: 100, isUploading: false });
  //   firebase
  //     .storage()
  //     .ref("images")
  //     .child(filename)
  //     .getDownloadURL()
  //     .then(url => this.setState({ avatarURL: url }));
  // };

  render() {
    const { profile } = this.props;
    let image;
    let action;
    let action2;
    let action3;
    let action4;

    if (profile.avatarURL === "") {
      image = daniel;
    } else {
      image = profile.avatarURL;
    }
    if (profile.type === "Hours") {
      action = profile.horas;
    } else {
      action = profile.asistencias;
    }
    if (profile.type == "Hours") {
      action2 = "HOURS";
    } else {
      action2 = "ATTENDENCES";
    }
    // if (this.state.avatarURL != "") {
    //   action4 = (
    //     <button className="minscribir2" onClick={this.handleSubmit}>
    //       Update
    //     </button>
    //   );
    // }
    return (
      <div>
        {action3}
        <div className="uiwebappteammembercopy7">
          <div className="teammember">
            <div className="bg">
              <div className="danielgarza">{profile.name}</div>
              {/* <FileUploader
                accept="image/*"
                className="custom-file-input"
                name="avatar"
                randomizeFilename
                maxHeight="100"
                storageRef={firebase.storage().ref("images")}
                onUploadStart={this.handleUploadStart}
                onUploadError={this.handleUploadError}
                onUploadSuccess={this.handleUploadSuccess}
                onProgress={this.handleProgress}
              />
              {action4} */}

              <div className="groupcopy4">
                <img src={image} className="rectangle" alt="logo" />
              </div>
              <div className="profileMail">{profile.email}</div>
              <div className="attendences">{action2}</div>
              <div className="a23">{action}</div>
            </div>
          </div>
        </div>

        <div className="iconsmenuaccountsettings"></div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};

const mapDispatchToProps = dispatch => {
  return {
    changeProfilePic: activity => dispatch(changeProfilePic(activity))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ProfileInfo);
