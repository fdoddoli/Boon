import React, { Component } from "react";
import "../../../HomeTest.css";
import DefaultActivityIcon from "../../../img/defaultActivityIcon.png";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import calendar from "../../../img/calendar.png";
import pinPoint from "../../../img/pinPoint.png";
import { publishActivity } from "../../../Actions/activityActions";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class StudentAdminActivityInfo extends Component {
  state = {
    id: this.props.match.params.id,
    school: ""
  };

  handleSubmit = e => {
    this.props.publishActivity(this.state);
  };
  render() {
    const id = this.props.match.params.id;
    const { activity } = this.props;
    let action;

    if (activity) {
      if (activity.avatarURL === "") {
        var image = DefaultActivityIcon;
      } else {
        image = activity.avatarURLP;
      }
      return (
        <div>
          <div className="whiteBackroundDetaileA"></div>
          <div className="titleDetaileA">
            {activity.title}
            {action}
          </div>
          <img src={image} className="dfotoDetaileA" alt="logo" />

          <div className="timeDetaileA">{activity.hours} hrs</div>
          <div className="ddescDetaileA">{activity.desc}</div>
          <div className="dateDetaileA">
            {activity.startDate} - {activity.endDate}
          </div>

          <img src={calendar} className="calendarDetaileA" alt="logo" />
          <img src={pinPoint} className="pinPointDetaileA" alt="logo" />
          <div className="adressDetaileA">{activity.address}</div>
        </div>
      );
    } else {
      return <div></div>;
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  const id = ownProps.match.params.id;
  const useradmins = state.firestore.data.UsersAdmin;
  const useradmin = useradmins ? useradmins[id] : null;
  return {
    activity: useradmin
  };
};
const mapDispatchToProps = dispatch => {
  return {
    publishActivity: activity => dispatch(publishActivity(activity))
  };
};
export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  firestoreConnect([{ collection: "UsersAdmin" }])
)(StudentAdminActivityInfo);
