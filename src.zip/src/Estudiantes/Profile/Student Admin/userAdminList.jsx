import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "./userAdminDetaile";

class UserAdminList extends Component {
  render() {
    const { activitys } = this.props;
    const { profile } = this.props;

    var today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    today = yyyy + "-" + mm + "-" + dd;

    return (
      <div className="pprruueebbaa">
        <ul className="ulllll">
          {activitys &&
            activitys.map(activity => {
              if (
                activity.student === profile.email &&
                today < activity.endDate
              ) {
                return (
                  <Link to={"/home/studentAdmin/" + activity.id}>
                    <ActivityDetaile activity={activity} key={activity.id} />
                  </Link>
                );
              } else {
                return null;
              }
            })}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.UsersAdmin,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "UsersAdmin" }])
)(UserAdminList);
