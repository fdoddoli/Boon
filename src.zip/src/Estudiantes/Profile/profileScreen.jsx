import React, { Component } from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { NavLink } from "react-router-dom";
import menuBar from "../../img/menuBar.png";
import { connect } from "react-redux";
import "../../HomeTest.css";
import triangle from "../../img/triangleDropDown.png";
import firebase from "firebase";
import {
  ActionItem,
  DropDownMenu,
  DropDownDirection
} from "react-dropdown-advanced";
import ProfileInfo from "./Information/profileInfo";
import UserAdminList from "./Student Admin/userAdminList";
import UpcomingActivityInfo from "./Upcoming Activities/upcomingActivityInfo";
import UpcomingActivityList from "./Upcoming Activities/upcomingActivityList";
import StudentAdminActivityInfo from "./Student Admin/studentAdminActivityInfo";
import HistoryTable from "./History/historyTable";
//import ExploreList from "./Explore/exploreList";
//import ExploreActivities from "./Explore/exploreActivities";

const profileRoutes = [
  {
    path: "/profile",
    exact: true,
    sidebar: () => <div>1</div>,
    main: () => <ProfileInfo />
  },
  {
    path: "/profile/history",
    exact: true,
    sidebar: () => <div>2</div>,
    main: HistoryTable
  },
  // {
  //   path: "/profile/explore",
  //   exact: true,
  //   sidebar: () => <div>3</div>,
  //   main: ExploreList
  // },
  // {
  //   path: "/activities/:id",
  //   exact: true,
  //   main: ExploreActivities
  // }
];

class ProfileScreen extends Component {
  logout = () => {
    firebase.auth().signOut();
  };
  getDynamicItems = () => {
    var arr: DropDownItemBase[] = [];
    arr.push(new ActionItem("logout", "Logout", ""));

    return arr;
  };
  render() {
    const { profile } = this.props;
    return (
      <div className="topbarmenu">
        <img src={menuBar} className="background" alt="logo" />
        <div className="home1">
          Profile
          <div className="logoutButton">
            <DropDownMenu
              getItems={this.getDynamicItems}
              onClick={this.logout}
              direction={DropDownDirection.DownRight}
            />

            <img src={triangle} alt="logo" />
          </div>
        </div>

        <div className="uiwebappcreatenewactivity">
          <div className="background1"></div>
        </div>
        <Router>
          <div className="activities1">
            <NavLink
              exact
              to="/profile"
              className="mainNavProfile"
              activeClassName="mainNavActive1"
            >
              General
            </NavLink>
            <NavLink
              to="/profile/history"
              className="mainNavProfile2"
              activeClassName="mainNavProfileActive2"
            >
              History
            </NavLink>
            {/* <NavLink
              to="/profile/explore"
              className="mainNavProfile3"
              activeClassName="mainNavProfileActive3"
            >
              Explore
            </NavLink> */}
          </div>
          {profileRoutes.map(route => (
            <Route
              key={route.path}
              path={route.path}
              exact={route.exact}
              component={route.main}
            />
          ))}
        </Router>
        <div className="rectangle2"></div>
        <div className="rectangle3"></div>
        <div className="user">Hi, {profile.name}</div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};

export default connect(mapStateToProps)(ProfileScreen);
