import React, { Component } from "react";
import menuBar from "../../img/menuBar.png";
import "../../HomeTest.css";
import firebase from "firebase";
import triangle from "../../img/triangleDropDown.png";
import { connect } from "react-redux";
import ActivityList from "./activityList";
import UpcomingActivityList from "../Profile/Upcoming Activities/upcomingActivityList";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { NavLink } from "react-router-dom";
import Popup from "reactjs-popup";
import {
  NotificationContainer,
  NotificationManager
} from "react-notifications";
import "react-notifications/lib/notifications.css";
import "../../App.css";
import { createActivity } from "../../Actions/activityActions";
import { clearActivity } from "../../Actions/activityActions";
import { clearSignUp } from "../../Actions/activityActions";
import {
  ActionItem,
  DropDownMenu,
  DropDownDirection
} from "react-dropdown-advanced";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from "@material-ui/pickers";
import NotificationsList from "../Notifications/notificationsList";
import FileUploader from "react-firebase-file-uploader";
import NotificationsBar from "../../img/notificationsBar.png";
import ActivityInfo from "./activityInfo";
import UpcommingInfo from "../Profile/Upcoming Activities/upcomingActivityInfo";
import StudentAdmin from "../Profile/Student Admin//userAdminList";
import NotificationsIcon from "../../img/notificationsIcon.png";
import StudentAdminInfo from "../Profile/Student Admin/studentAdminActivityInfo";
require("react-dropdown-advanced/styles/rdropdown.css");

//Home Screen
const homeRoutes = [
  {
    path: "/home",
    exact: true,
    main: ActivityList
  },
  {
    path: "/home/upcomingactivities",
    exact: true,
    main: UpcomingActivityList
  },
  {
    path: "/home/studentadmin",
    exact: true,
    main: StudentAdmin
  },

  {
    path: "/activity/:id",
    exact: true,
    main: ActivityInfo
  },
  {
    path: "/home/studentAdmin/:id",
    exact: true,
    main: StudentAdminInfo
  },
  {
    path: "/home/upcomming/:id",
    exact: true,
    main: UpcommingInfo
  }
];
class HomeScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      image: "",
      avatar: "",
      username: "",
      isUploading: false,
      currentSignUps: 0,
      progress: 0,
      avatarURL: "",
      title: "",
      desc: "",
      hours: 0,
      size: 0,
      address: "",
      pdf: "",
      startDate: null,
      endDate: null,
      activityCode: "",
      status: "Enviado",
      error: "",
      open: false,
      notificationOpen: false,
      frequency: "Weekly"
    };
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.setWrapperRef = this.setWrapperRef.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
  }
  componentDidMount() {
    document.addEventListener("mousedown", this.handleClickOutside);
  }

  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside);
  }
  openModal() {
    this.setState({ open: true });
  }
  closeModal() {
    this.setState({ open: false });
  }
  logout = () => {
    firebase.auth().signOut();
  };
  getDynamicItems() {
    var arr: DropDownItemBase[] = [];
    arr.push(new ActionItem("logout", "Logout", ""));
    return arr;
  }
  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.createActivity(this.state);
  };
  handleSubmit2 = e => {
    this.setState({ error: "" });
    this.setState({ avatarURL: "" });
    this.setState({ title: "" });
    this.setState({ desc: "" });
    this.setState({ size: "" });
    this.setState({ activityCode: "" });
    this.setState({ address: "" });
    this.setState({ startDate: "" });
    this.setState({ endDate: "" });
    this.setState({ pdf: "" });
    this.setState({ hours: "" });
    this.props.clearActivity(this.state);
  };

  handleSubmitNotifications = e => {
    if (this.state.notificationOpen) {
      this.setState({ notificationOpen: false });
    } else {
      this.setState({ notificationOpen: true });
    }
  };

  handleChangeUsername = event =>
    this.setState({ username: event.target.value });
  handleUploadStart = () => this.setState({ isUploading: true, progress: 0 });
  handleProgress = progress => this.setState({ progress });
  handleUploadError = error => {
    this.setState({ isUploading: false });
  };
  handleUploadSuccess = filename => {
    this.setState({ avatar: filename, progress: 100, isUploading: false });
    firebase
      .storage()
      .ref("images")
      .child(filename)
      .getDownloadURL()
      .then(url => this.setState({ avatarURL: url }));
  };

  handleChangeUsernamePDF = event =>
    this.setState({ username: event.target.value });
  handleUploadStartPDF = () =>
    this.setState({ isUploading: true, progress: 0 });
  handleProgressPDF = progress => this.setState({ progress });
  handleUploadErroPDF = error => {
    this.setState({ isUploading: false });
  };
  handleUploadSuccessPDF = filename => {
    this.setState({ avatarPDF: filename, progress: 100, isUploading: false });
    firebase
      .storage()
      .ref("images")
      .child(filename)
      .getDownloadURL()
      .then(url => this.setState({ pdf: url }));
  };

  handleSuccessfullySignedUp = e => {
    this.props.clearSignUp(this.state);
  };

  handleDateChange = date => {
    console.log(date);
    this.setState({ startDate: date });
  };

  handleDateChangeEnd = date => {
    console.log(date);
    this.setState({ endDate: date });
  };

  setWrapperRef(node) {
    this.wrapperRef = node;
  }
  handleClickOutside(event) {
    if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
      this.setState({ notificationOpen: false });
    }
  }
  render() {
    const { profile, activityError, signUpError } = this.props;
    let action;
    let action2;
    var today = new Date();
    console.log(this.state.startDate < this.state.endDate);
    if (this.state.notificationOpen) {
      action2 = (
        <div className="DropDownNotifications" ref={this.setWrapperRef}>
          <img className="imgNotifications" src={NotificationsBar} alt="logo" />
          <div className="NotificationsTitle">Notifications</div>
          <NotificationsList />
        </div>
      );
    }
    let error = this.state.error ? (
      <div className="catchError"> {this.state.error}</div>
    ) : null;
    if (activityError == "Activity Sucessfully Created") {
      NotificationManager.success(
        "Waiting for Teacher's Aproval",
        "Activity Sucessfully Created"
      );

      this.handleSubmit2();

      this.closeModal();
    }
    if (signUpError == "Successfully signed up.") {
      NotificationManager.success("Success", "Signed Up!");

      this.handleSuccessfullySignedUp();
    }
    if (profile.type == "Hours") {
      action = (
        <div>
          <div className="aInfor">Hours / Attendance</div>
          <form>
            <input
              type="number"
              placeholder="Hours Gained"
              className="abHours"
              value={this.state.hours}
              onChange={this.handleChange}
              name="hours"
            />
          </form>
        </div>
      );
    }
    return (
      <div>
        <NotificationContainer />
        <div className="topbarmenu">
          <img src={menuBar} className="background" alt="logo" />
          <div className="home1">
            Home
            <div className="logoutButton">
              <DropDownMenu
                getItems={this.getDynamicItems}
                onClick={this.logout}
                direction={DropDownDirection.DownRight}
              />
              <img src={triangle} className="logOutTriangle" alt="logo" />
            </div>
          </div>
          <div className="rectangle2"></div>
          <div className="rectangle3"></div>
          <div className="user">Hi, {profile.name}</div>

          <Router>
            <div className="activities1">
              <NavLink
                exact
                to="/home"
                className="mainNav3"
                activeClassName="mainNavActive1"
              >
                Activities
              </NavLink>
              <NavLink
                to="/home/upcomingactivities"
                className="mainNav"
                activeClassName="mainNavActive2"
              >
                Upcoming Activities
              </NavLink>
              <NavLink
                to="/home/studentadmin"
                className="mainNav2"
                activeClassName="mainNavActive3"
              >
                Student Admin
              </NavLink>
            </div>
            {homeRoutes.map(route => (
              <Route
                key={route.path}
                path={route.path}
                exact={route.exact}
                component={route.main}
              />
            ))}
          </Router>
          <div className="NotificationButton">
            {action2}
            <img
              onClick={this.handleSubmitNotifications}
              src={NotificationsIcon}
              className="notificationBell"
              alt="logo"
            />
          </div>
        </div>
        <button className="uiwebappcreatenewactivity" onClick={this.openModal}>
          <div className="rectangle21">
            <div className="group">
              <div className="createanewactivit">+ Propose Activiy</div>
            </div>
          </div>
        </button>
        <Popup
          open={this.state.open}
          closeOnDocumentClick
          onClose={this.closeModal}
        >
          <div className="modal">
            <a className="close" onClick={this.closeModal}>
              &times;
            </a>
            <div className="actividadespublicadascopy7">
              <div className="cActivityTitle">Propose Activity</div>
              <div className="catchError">{activityError}</div>
              <div className="aImage">Image</div>
              <form>
                {this.state.isUploading && (
                  <p>Progress: {this.state.progress}</p>
                )}
                <FileUploader
                  accept="image/*"
                  className="abImage"
                  name="avatar"
                  randomizeFilename
                  maxHeight="350"
                  storageRef={firebase.storage().ref("images")}
                  onUploadStart={this.handleUploadStart}
                  onUploadError={this.handleUploadError}
                  onUploadSuccess={this.handleUploadSuccess}
                  onProgress={this.handleProgress}
                />

                <div className="aTitle">Activity Title</div>

                <input
                  type="text"
                  placeholder="Title "
                  className="abTitle"
                  value={this.state.title}
                  onChange={this.handleChange}
                  name="title"
                  required
                />
                <div className="aDesc">Description</div>
                <textarea
                  name="desc"
                  placeholder="Please write a description of the activity, including start time and end time and any other helpful information"
                  className="abDesc"
                  onChange={this.handleChange}
                  value={this.state.desc}
                />
                <div className="aSize"># of Volunteers</div>
                <input
                  type="number"
                  placeholder="Size "
                  className="abSize"
                  value={this.state.size}
                  onChange={this.handleChange}
                  name="size"
                />
                <div className="aID">Frequency</div>
                <select
                  name="frequency"
                  placeholder="Select Frequency"
                  className="abID"
                  onChange={this.handleChange}
                >
                  <option value="Weekly">Weekly</option>
                  <option value="One Time">One Time</option>
                </select>

                <div className="aMentor">Address</div>

                <input
                  type="text"
                  placeholder="Address"
                  className="abMentor"
                  value={this.state.address}
                  onChange={this.handleChange}
                  name="address"
                />
                <div className="aDate">Start Date</div>
                <div className="dateHelper">
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDatePicker
                      disableToolbar
                      variant="inline"
                      format="MM/dd/yyyy"
                      margin="normal"
                      name="startDate"
                      label=""
                      value={this.state.startDate}
                      onChange={this.handleDateChange}
                      KeyboardButtonProps={{
                        "aria-label": "change date"
                      }}
                    />
                  </MuiPickersUtilsProvider>
                </div>
                <div className="aDate2">End Date</div>
                <div className="dateHelper2">
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <KeyboardDatePicker
                      disableToolbar
                      variant="inline"
                      format="MM/dd/yyyy"
                      margin="normal"
                      name="endDate"
                      label=""
                      value={this.state.endDate}
                      onChange={this.handleDateChangeEnd}
                      KeyboardButtonProps={{
                        "aria-label": "change date"
                      }}
                    />
                  </MuiPickersUtilsProvider>
                </div>
                <div className="aTime">Activity ID#</div>
                {error}
                <input
                  type="text"
                  placeholder="Activity ID# "
                  className="abTime"
                  value={this.state.activityCode}
                  onChange={this.handleChange}
                  name="activityCode"
                />
              </form>

              {action}

              <button className="bCreateA" onClick={this.handleSubmit}>
                <div className="createActivityWhite"> Propose Activity </div>
              </button>
            </div>
          </div>
        </Popup>
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    auth: state.firebase.auth,
    profile: state.firebase.profile,
    signUpError: state.activitys.signUpError,
    activityError: state.activitys.activityError
  };
}
const mapDispatchToProps = dispatch => {
  return {
    createActivity: activity => dispatch(createActivity(activity)),
    clearActivity: activity => dispatch(clearActivity(activity)),
    clearSignUp: activity => dispatch(clearSignUp(activity))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(HomeScreen);
