import React, { Component } from "react";
import { connect } from "react-redux";
import "../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import Loader from "react-loader-spinner";
import ActivityDetaile from "../../activityDetaile";

class ActivityList extends Component {
  render() {
    const { activitys } = this.props;
    const { profile } = this.props;
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    today = yyyy + "-" + mm + "-" + dd;
    if (activitys != null) {
      return (
        // <div className="pprruueebbaa2">
        // <ul className="ulllll2">
        <div className="pprruueebbaa">
          <ul className="ulllll">
            {activitys &&
              activitys.map(activity => {
                if (
                  profile.schoolCode === activity.school &&
                  activity.status === "Autorizado" &&
                  today < activity.startDate
                ) {
                  return (
                    <Link to={"/activity/" + activity.id}>
                      <ActivityDetaile activity={activity} key={activity.id} />
                    </Link>
                  );
                } else {
                  return null;
                }
              })}
          </ul>
        </div>
      );
    } else {
      return (
        <div className="spinner">
          <Loader
            type="TailSpin"
            color="rgba(231, 91, 16, 1.0)"
            height={150}
            width={150}
          />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  console.log(state);
  return {
    activitys: state.firestore.ordered.Actividades,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect(props => {
    if (props.profile.schoolCode == undefined) return [];
    else {
      return [
        {
          collection: "Actividades",
          where: ["school", "==", props.profile.schoolCode]
        }
      ];
    }
  })
)(ActivityList);
