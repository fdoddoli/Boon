import React, { Component } from "react";
import "./HomeTest.css";
import DefaultActivityIcon from "./img/defaultActivityIcon.png";
import Backround from "./img/whiteBackround.png";
import Cohete from "./img/cohete.png";
import Loader from "react-loader-spinner";
import Img from "react-image";

const ActivityDetaile = ({ activity }) => {
  let action;
  if (activity.avatarURL == "") {
    var image = DefaultActivityIcon;
  } else {
    var image = activity.avatarURL;
  }
  if (activity.hours != "") {
    action = (
      <div className="horasDetaile">
        <img src={Cohete} className="cohete" alt="logo" />
        <div className="hrsDetaile">{activity.hours} hrs</div>
      </div>
    );
  }
  let startDate = activity.startDate.substring(5, 7);
  let endDate = activity.endDate.substring(5, 7);
  let action2;
  let action3;
  if (endDate == "01") {
    action3 = (
      <div className="endDate">
        Jan-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "01") {
    action2 = (
      <div className="startDate">
        Jan-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "02") {
    action3 = (
      <div className="endDate">
        Feb-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "02") {
    action2 = (
      <div className="startDate">
        Feb-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "03") {
    action3 = (
      <div className="endDate">
        Mar-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "03") {
    action2 = (
      <div className="startDate">
        Mar-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "04") {
    action3 = (
      <div className="endDate">
        Apr-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "04") {
    action2 = (
      <div className="startDate">
        Apr-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "05") {
    action3 = (
      <div className="endDate">
        May-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "05") {
    action2 = (
      <div className="startDate">
        May-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "06") {
    action3 = (
      <div className="endDate">
        Jun-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "06") {
    action2 = (
      <div className="startDate">
        Jun-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "07") {
    action3 = (
      <div className="endDate">
        Jul-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "07") {
    action2 = (
      <div className="startDate">
        Jul-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "08") {
    action3 = (
      <div className="endDate">
        Aug-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "08") {
    action2 = (
      <div className="startDate">
        Aug-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "09") {
    action3 = (
      <div className="endDate">
        Sep-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "09") {
    action2 = (
      <div className="startDate">
        Sep-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "10") {
    action3 = (
      <div className="endDate">
        Oct-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "10") {
    action2 = (
      <div className="startDate">
        Oct-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "11") {
    action3 = (
      <div className="endDate">
        Nov-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "11") {
    action2 = (
      <div className="startDate">
        Nov-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "12") {
    action3 = (
      <div className="endDate">
        Dec-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "12") {
    action2 = (
      <div className="startDate">
        Dec-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  return (
    <li className="listaActividades">
      <div className="containers">
        <img src={Backround} className="backround" alt="logo" />
        <img src={image} className="photo1" alt="logo" />

        <div className="post">{activity.title}</div>

        <div className="rectangle10"></div>

        <div className="date">
          {action2}
          {action3}
        </div>
        <div className="pruebaaData">Activity #{activity.activityCode}</div>
        {action}
      </div>
    </li>
  );
};

export default ActivityDetaile;
