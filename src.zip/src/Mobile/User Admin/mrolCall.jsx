import React, { Component } from "react";
import "../../HomeTest.css";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import { rolCallActivity } from "../../Actions/activityActions";
import MRolCallInfo from "./mRollCallInfo";
import MRolCallInfo2 from "./mRolCallInfoHours";
import Popup from "reactjs-popup";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class MRolCall extends Component {
  render() {
    const { activity } = this.props;
    const { profile } = this.props;
    const { estudiantes } = this.props;
    return (
      <div>
        <div className="check123456789">
          <div className="pprruueebbaa4">
            <ul className="ulllll3">
              {estudiantes &&
                estudiantes.map(estudiante => {
                  if (estudiante.title === activity.title) {
                    if (profile.type == "Hours") {
                      return (
                        <div>
                          <MRolCallInfo2
                            estudiante={estudiante}
                            key={estudiante.id}
                          />
                        </div>
                      );
                    } else {
                      return (
                        <div>
                          <MRolCallInfo
                            estudiante={estudiante}
                            key={estudiante.id}
                          />
                        </div>
                      );
                    }
                  } else {
                    return null;
                  }
                })}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  const id = ownProps.match.params.id;
  const activitys = state.firestore.data.UsersAdmin;
  const activity = activitys ? activitys[id] : null;

  return {
    activity: activity,
    estudiantes: state.firestore.ordered.ActividadesyUsuarios,
    profile: state.firebase.profile
  };
};
const mapDispatchToProps = dispatch => {
  return {
    rolCallActivity: activitys => dispatch(rolCallActivity(activitys))
  };
};
export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  firestoreConnect([
    { collection: "ActividadesyUsuarios" },
    { collection: "UsersAdmin" }
  ])
)(MRolCall);
