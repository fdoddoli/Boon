import React, { Component } from "react";
import { connect } from "react-redux";
import "../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "./userAdminDetaile";

class MActivityListUserAdmin extends Component {
  render() {
    const { activitys } = this.props;
    const { profile } = this.props;

    return (
      <div className="pprruueebbaa3">
        <ul className="ulllll3">
          {activitys &&
            activitys.map(activity => {
              if (activity.student === profile.email) {
                return (
                  <Link to={"/roleCall/" + activity.id}>
                    <ActivityDetaile activity={activity} key={activity.id} />
                  </Link>
                );
              } else {
                return null;
              }
            })}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.UsersAdmin,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "UsersAdmin" }])
)(MActivityListUserAdmin);
