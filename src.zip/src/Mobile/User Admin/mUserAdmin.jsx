import React, { Component } from "react";
import "../../HomeTest.css";
import MActivityList from "./mActivityListUserAdmin";
import "../../App.css";

//Mobile Home Screen
class StudentAdmin extends Component {
  render() {
    return (
      <div className="check1234567">
        <MActivityList />
      </div>
    );
  }
}

export default StudentAdmin;
