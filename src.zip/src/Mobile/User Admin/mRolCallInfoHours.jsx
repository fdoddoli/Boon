import React, { Component } from "react";
import "../../HomeTest.css";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import { rolCallActivity } from "../../Actions/activityActions";
import Popup from "reactjs-popup";
import daniel from "../../img/daniel.jpg";
import rollON from "../../img/Days.png";
import rollOFF from "../../img/Days2.png";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class mRollCallInfoHours extends Component {
  state = {
    grade: "",
    gradeDesc: "",
    graded: rollOFF,
    open: false
  };

  handleSubmit = e => {
    const { estudiante } = this.props;
    this.props.rolCallActivity(estudiante, this.state);
    this.setState({ graded: rollON });
    this.closeModal();
  };
  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  closeModal = e => {
    this.setState({ open: false });
  };
  openModal = e => {
    this.setState({ open: true });
  };
  render() {
    const { estudiante } = this.props;
    let { roll } = this.props;
    let action;
    let action2;
    if (estudiante.avatarURLP) {
      action = estudiante.avatarURLP;
    } else {
      action = daniel;
    }
    if (this.state.graded === rollON) {
      action2 = (
        <div className="assistButton">
          <img src={this.state.graded} className="assistRoll" alt="logo" />
        </div>
      );
    } else {
      action2 = (
        <button className="assistButton" onClick={this.openModal}>
          <img src={this.state.graded} className="assistRoll" alt="logo" />
        </button>
      );
    }
    return (
      <div>
        <li className="mRStudentContainer">
          <img src={action} className="mphoto123" alt="logo" />
          <div className="rolName">{estudiante.studentName}</div>
          <div className="rolName">{estudiante.studentEmail}</div>
          {action2}
          <Popup
            open={this.state.open}
            closeOnDocumentClick
            onClose={this.closeModal}
          >
            <div className="modal">
              <div className="actividadespublicadascopy78">
                <div className="gradeTitle2">Assistance</div>
                <div className="mRectangle20"></div>
                <div className="commentGrade">Comments on Student</div>
                <form>
                  <textarea
                    rows="10"
                    cols="30"
                    className="abexplain2"
                    value={this.state.gradeDesc}
                    onChange={this.handleChange}
                    name="gradeDesc"
                  />
                </form>
                <button className="msend2" onClick={this.handleSubmit}>
                  Send
                </button>
                <div className="rollCatch">{roll}</div>
              </div>
            </div>
          </Popup>
        </li>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    roll: state.activitys.roll
  };
};
const mapDispatchToProps = dispatch => {
  return {
    rolCallActivity: (activitys, grade) =>
      dispatch(rolCallActivity(activitys, grade))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(mRollCallInfoHours);
