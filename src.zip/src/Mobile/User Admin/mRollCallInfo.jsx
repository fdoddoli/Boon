import React, { Component } from "react";
import "../../HomeTest.css";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import { rolCallActivity } from "../../Actions/activityActions";
import Popup from "reactjs-popup";
import daniel from "../../img/daniel.jpg";
import rollON from "../../img/Days.png";
import rollOFF from "../../img/Days2.png";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class mRollCallInfo extends Component {
  state = {
    grade: "",
    gradeDesc: "",
    graded: rollOFF
  };

  handleSubmit = e => {
    const { estudiante } = this.props;
    this.props.rolCallActivity(estudiante, this.state);
    this.setState({ graded: rollON });
  };
  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  render() {
    const { estudiante } = this.props;
    let { roll } = this.props;
    let action;
    if (estudiante.avatarURLP) {
      action = estudiante.avatarURLP;
    } else {
      action = daniel;
    }
    return (
      <div>
        <li className="mRStudentContainer">
          <img src={action} className="mphoto123" alt="logo" />
          <div className="rolName">{estudiante.studentName}</div>
          <div className="rolName">{estudiante.studentEmail}</div>

          <Popup
            trigger={
              <button className="assistButton">
                <img
                  src={this.state.graded}
                  className="assistRoll"
                  alt="logo"
                />
              </button>
            }
            modal
          >
            {close => (
              <div className="modal">
                <div className="actividadespublicadascopy78">
                  <div className="gradeTitle">Grade</div>
                  <div className="mRectangle20"></div>
                  <div>
                    <div className="nameGrade">
                      Please give a grade to {estudiante.studentName}
                    </div>
                    <form>
                      <input
                        type="text"
                        placeholder="Grade "
                        className="abgrade"
                        value={this.state.grade}
                        onChange={this.handleChange}
                        name="grade"
                      />
                    </form>
                  </div>
                  <div className="mRectangle21"></div>
                  <div className="explainGrade">Please explain your grade</div>
                  <form>
                    <textarea
                      rows="10"
                      cols="30"
                      className="abexplain"
                      value={this.state.gradeDesc}
                      onChange={this.handleChange}
                      name="gradeDesc"
                    />
                  </form>
                  <button className="msend" onClick={this.handleSubmit}>
                    Send
                  </button>
                </div>
              </div>
            )}
          </Popup>
        </li>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    roll: state.activitys.roll
  };
};
const mapDispatchToProps = dispatch => {
  return {
    rolCallActivity: (activitys, grade) =>
      dispatch(rolCallActivity(activitys, grade))
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(mRollCallInfo);
