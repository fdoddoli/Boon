import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import { NavLink } from "react-router-dom";
import "../../HomeTest.css";
import { connect } from "react-redux";

class HomeTestMobile extends Component {
  constructor() {
    super();
    this.state = {};
  }
  render() {
    const { profile } = this.props;
    return (
      <div>
        <Router>
          <div style={{ display: "flex" }}>
            <div
              style={{
                padding: "0%",
                height: "17%",
                width: "100%"
              }}
            >
              <NavLink
                to="/mobile/home"
                className=""
                onClick={this.toggleIconHome}
              >
                <img src={this.state.homeUrl} className="" alt="logo" />
              </NavLink>
              <NavLink
                to="/mobile/profile"
                className=""
                onClick={this.toggleIconProfile}
              >
                <img src={this.state.profileUrl} className="" alt="logo" />
              </NavLink>
            </div>
          </div>
          {routes.map(route => (
            <Route
              key={route.path}
              path={route.path}
              exact={route.exact}
              component={route.main}
            />
          ))}
        </Router>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};
export default connect(mapStateToProps)(HomeTestMobile);
