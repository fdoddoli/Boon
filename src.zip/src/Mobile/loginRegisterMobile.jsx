import React, { Component } from "react";
import "../HomeTest.css";
import logoNombre from "../img/boon logoBlack.png";
import firebase from "firebase";

class LoginRegisterMobile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      fireErrors: ""
    };
  }

  login = e => {
    e.preventDefault();
    firebase
      .auth()
      .signInWithEmailAndPassword(this.state.email, this.state.password)
      .catch(error => {
        this.setState({ fireErrors: error.message });
      });
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    let errorNotification = this.state.fireErrors ? (
      <div className="errorMobileLog"> {this.state.fireErrors}</div>
    ) : null;

    return (
      <div>
        <img src={logoNombre} className="mobileLogo" alt="logo" />
        <div className="itseasy">Its's easy.</div>
        <div>
          <form>
            <input
              type="text"
              placeholder="Email "
              className="StudentusernameM"
              value={this.state.email}
              onChange={this.handleChange}
              name="email"
            />
          </form>
          <form>
            <input
              type="text"
              placeholder="Password "
              className="StudentpasswordM"
              value={this.state.password}
              onChange={this.handleChange}
              name="password"
            />
          </form>
        </div>
        <button className="mloginIn" onClick={this.login}>
          <div className="white">LOG IN</div>
        </button>
        {errorNotification}
      </div>
    );
  }
}
export default LoginRegisterMobile;
