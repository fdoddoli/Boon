import React, { Component } from "react";
import "../../HomeTest.css";
import { connect } from "react-redux";

class MSettingsScreen extends Component {
  render() {
    const { profile } = this.props;
    return (
      <div>
        <div className="mNombre">Name</div>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="NameSettingsMobile "
            readOnly
            value={profile.name}
            name="name"
          />
        </form>

        <div className="mEmail">Email</div>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="EmailSettingsMobile "
            readOnly
            value={profile.email}
            name="name"
          />
        </form>
        <div className="mId">Student ID</div>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="StudentSettingsMobile "
            readOnly
            value={profile.studentID}
            name="name"
          />
        </form>
        <div className="mSchool">School Code</div>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="SchoolSettingsMobile "
            readOnly
            value={profile.schoolCode}
            name="name"
          />
        </form>
        <div className="mPassword">Password</div>
        <form>
          <input
            type="text"
            placeholder="Name "
            className="PasswordSettingsMobile "
            readOnly
            value="********"
            name="name"
          />
        </form>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};

export default connect(mapStateToProps)(MSettingsScreen);
