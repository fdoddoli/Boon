import React, { Component } from "react";
import firebase from "firebase";
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import { NavLink } from "react-router-dom";
import "../HomeTest.css";
import homeImage from "../img/buttonHome.png";
import homeImageActive from "../img/homeButton.png";
import profileImage from "../img/Picture2.png";
import profileImageActive from "../img/Picture1.png";
import HomeScreen from "./Home/mHomeScreen";
import ProfileScreen from "./Profile/mProfileScreen";
import SettingsScreen from "./Settings/mSettingsScreen";
import ActivityInfo from "./Home/mActivityInfo";
import UActivityInfo from "./Profile/Upcoming Activity/mUpcommingActivityInfo";
import UserAdmin from "./User Admin/mUserAdmin";
import { connect } from "react-redux";
import daniel from "../img/daniel.jpg";
import Sidebar from "react-sidebar";
import Close from "../img/decline.png";
import RolCall from "./User Admin/mrolCall";
import Burger from "../img/burger.png";

const mql = window.matchMedia(`(min-width: 800px)`);

//Mobile Routes
const routes = [
  {
    path: "/mobile/home",
    exact: true,
    main: HomeScreen
  },
  {
    path: "/mobile/profile",
    exact: true,
    main: ProfileScreen
  },
  {
    path: "/activity/:id",
    exact: true,
    main: ActivityInfo
  },
  {
    path: "/mobile/upcomingActivity/:id",
    exact: true,
    main: UActivityInfo
  },
  {
    path: "/roleCall/:id",
    exact: true,
    main: RolCall
  },
  {
    path: "/mobile/studentAdmin",
    exact: true,
    main: UserAdmin
  },
  {
    path: "/mobile/settings",
    exact: true,
    main: SettingsScreen
  }
];
class HomeTestMobile extends Component {
  //The mainComponent sidebar and mainBackround
  constructor() {
    super();
    this.state = {
      homeUrl: homeImageActive,
      profileUrl: profileImage,
      title: "Home",
      sidebarOpen: false,
      sidebarDocked: mql.matches
    };
    this.onSetSidebarOpen = this.onSetSidebarOpen.bind(this);
    this.mediaQueryChanged = this.mediaQueryChanged.bind(this);
    this.onSetSidebarOpen = this.onSetSidebarOpen.bind(this);

    this.toggleIconHome = this.toggleIconHome.bind(this);
    this.toggleIconProfile = this.toggleIconProfile.bind(this);
    this.toggleIconStudentAdmin = this.toggleIconStudentAdmin.bind(this);
    this.toggleIconSettings = this.toggleIconSettings.bind(this);
  }
  //function that changes sidebar selected image icon
  toggleIconHome() {
    this.setState({ homeUrl: homeImageActive });
    this.setState({ profileUrl: profileImage });
    this.setState({ title: "Home" });
  }
  toggleIconProfile() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImageActive });
    this.setState({ title: "Profile" });
  }
  toggleIconStudentAdmin() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImage });
    this.setState({ title: "Student Admin Activities" });
    this.onSetSidebarOpen(false);
  }
  toggleIconSettings() {
    this.setState({ homeUrl: homeImage });
    this.setState({ profileUrl: profileImage });
    this.setState({ title: "Settings" });
    this.onSetSidebarOpen(false);
  }
  //open sideBar function
  onSetSidebarOpen(open) {
    this.setState({ sidebarOpen: open });
  }
  //function to make sidebar responsive
  componentWillMount() {
    mql.addListener(this.mediaQueryChanged);
  }

  componentWillUnmount() {
    mql.removeListener(this.mediaQueryChanged);
  }

  onSetSidebarOpen(open) {
    this.setState({ sidebarOpen: open });
  }

  mediaQueryChanged() {
    this.setState({ sidebarDocked: mql.matches, sidebarOpen: false });
  }
  //logout function firebase
  logout = () => {
    firebase.auth().signOut();
  };
  render() {
    const { profile } = this.props;
    let action;
    if (profile.avatarURL != "") {
      action = profile.avatarURL;
    } else {
      action = daniel;
    }
    return (
      <div>
        <Router>
          <Sidebar
            sidebar={
              <div>
                <div className="accountSideBar">Account</div>
                <img
                  src={Close}
                  onClick={() => this.onSetSidebarOpen(false)}
                  className="sideBarClose"
                  alt="logo"
                />
                <div className="mSRectangle10"></div>

                <NavLink to="/mobile/home">
                  <img src={action} className="sideBarFoto" alt="logo" />
                </NavLink>
                <div className="nameSideBar">{profile.name}</div>
                <div className="emailSideBar">{profile.email}</div>
                <div className="mSRectangle11"></div>
                <NavLink
                  to="/mobile/studentAdmin"
                  className="StudentAdmin"
                  onClick={this.toggleIconStudentAdmin}
                >
                  <div className="sbStudentAdm">Student Admin</div>
                </NavLink>
                <NavLink
                  to="/mobile/settings"
                  className="mSettings"
                  onClick={this.toggleIconSettings}
                >
                  <div>Settings</div>
                </NavLink>
                <button className="mSignOut" onClick={this.logout}>
                  Sign Out
                </button>
              </div>
            }
            open={this.state.sidebarOpen}
            onSetOpen={this.onSetSidebarOpen}
            styles={{
              sidebar: { background: "white", width: 300 },
              root: {
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                overflow: "hidden"
              }
            }}
          ></Sidebar>
          <div className="mHomeTitle">{this.state.title}</div>
          <div className="mRectangle10Home"></div>

          <Redirect from="/" exact to="/mobile/home" />
          <div style={{ display: "flex" }}>
            <div
              style={{
                padding: "0%",
                height: "17%",
                width: "100%"
              }}
            >
              <img
                src={Burger}
                onClick={() => this.onSetSidebarOpen(true)}
                className="mobileFoto"
                alt="logo"
              />

              <NavLink
                to="/mobile/home"
                className="msideBarImage"
                onClick={this.toggleIconHome}
              >
                <img src={this.state.homeUrl} className="mHomeImg" alt="logo" />
              </NavLink>
              <NavLink
                to="/mobile/profile"
                className="msideBarImage2"
                onClick={this.toggleIconProfile}
              >
                <img
                  src={this.state.profileUrl}
                  className="mHomeImg"
                  alt="logo"
                />
              </NavLink>
            </div>
          </div>
          {routes.map(route => (
            <Route
              key={route.path}
              path={route.path}
              exact={route.exact}
              component={route.main}
            />
          ))}
        </Router>
      </div>
    );
  }
}
const mapStateToProps = state => {
  return {
    profile: state.firebase.profile
  };
};
export default connect(mapStateToProps)(HomeTestMobile);
