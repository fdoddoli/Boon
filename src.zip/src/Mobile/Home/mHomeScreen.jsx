import React, { Component } from "react";
import "../../HomeTest.css";
import firebase from "firebase";
import { connect } from "react-redux";
import MActivityList from "./mActivityList";
import "../../App.css";
import { createActivity } from "../../Actions/activityActions";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";

//Mobile Home Screen
class HomeScreen extends Component {
  render() {
    return (
      <div className="check1234567">
        <MActivityList />
      </div>
    );
  }
}

export default HomeScreen;
