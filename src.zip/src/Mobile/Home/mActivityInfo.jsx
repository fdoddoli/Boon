import React, { Component } from "react";
import "../../HomeTest.css";
import {
  NotificationContainer,
  NotificationManager
} from "react-notifications";
import DefaultActivityIcon from "../../img/defaultActivityIcon.png";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import calendar from "../../img/calendar.png";
import pinPoint from "../../img/pinPoint.png";
import Frequency from "../../img/frequency.png";
import Add from "../../img/Add.png";
import { signUpActivity } from "../../Actions/activityActions";
import { clearSignUp } from "../../Actions/activityActions";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class MactivityInfo extends Component {
  state = {
    id: this.props.match.params.id,
    image: "",
    title: "",
    desc: "",
    size: "",
    address: "",
    date: "",
    time: "",
    repeat: "",
    school: ""
  };

  handleSubmit = e => {
    const { activity } = this.props;
    const id = this.props.match.params.id;
    this.props.signUpActivity(activity, id);
  };
  handleSuccessfullySignedUp = e => {
    this.props.clearSignUp(this.state);
  };
  render() {
    const { activity, profile, signUpError } = this.props;
    let hr;
    let plusSign;

    if (signUpError == "Successfully signed up.") {
      NotificationManager.success("Success", "Signed Up!");

      this.handleSuccessfullySignedUp();
    }

    if (activity) {
      if (activity.avatarURL === "") {
        var image = DefaultActivityIcon;
      } else {
        image = activity.avatarURL;
      }
      if (profile.type === "Hours") {
        hr = <div className="mtimeDetaile">{activity.hours} hrs</div>;
        plusSign = <img src={Add} className="mhoursDetaile" alt="logo" />;
      }
      let startDate = activity.startDate.substring(5, 7);
      let endDate = activity.endDate.substring(5, 7);
      let action2;
      let action3;
      if (endDate == "01") {
        action3 = (
          <div className="endDate">
            Jan-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "01") {
        action2 = (
          <div className="startDate">
            Jan-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "02") {
        action3 = (
          <div className="endDate">
            Feb-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "02") {
        action2 = (
          <div className="startDate">
            Feb-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "03") {
        action3 = (
          <div className="endDate">
            Mar-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "03") {
        action2 = (
          <div className="startDate">
            Mar-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "04") {
        action3 = (
          <div className="endDate">
            Apr-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "04") {
        action2 = (
          <div className="startDate">
            Apr-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "05") {
        action3 = (
          <div className="endDate">
            May-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "05") {
        action2 = (
          <div className="startDate">
            May-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "06") {
        action3 = (
          <div className="endDate">
            Jun-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "06") {
        action2 = (
          <div className="startDate">
            Jun-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "07") {
        action3 = (
          <div className="endDate">
            Jul-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "07") {
        action2 = (
          <div className="startDate">
            Jul-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "08") {
        action3 = (
          <div className="endDate">
            Aug-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "08") {
        action2 = (
          <div className="startDate">
            Aug-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "09") {
        action3 = (
          <div className="endDate">
            Sep-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "09") {
        action2 = (
          <div className="startDate">
            Sep-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "10") {
        action3 = (
          <div className="endDate">
            Oct-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "10") {
        action2 = (
          <div className="startDate">
            Oct-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "11") {
        action3 = (
          <div className="endDate">
            Nov-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "11") {
        action2 = (
          <div className="startDate">
            Nov-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      if (endDate == "12") {
        action3 = (
          <div className="endDate">
            Dec-{activity.endDate.substring(8, 10)}-
            {activity.endDate.substring(0, 4)}
          </div>
        );
      }
      if (startDate == "12") {
        action2 = (
          <div className="startDate">
            Dec-{activity.startDate.substring(8, 10)}-
            {activity.startDate.substring(0, 4)} to
          </div>
        );
      }
      return (
        <div>
          <NotificationContainer />
          <img src={image} className="mdfotoDetaile" alt="logo" />
          <div className="mtitleSetaile">{activity.title}</div>
          {hr}
          {plusSign}
          <div className="mddescDetaile">{activity.desc}</div>
          <div className="mdateDetaile">
            {action2}
            {action3}
          </div>

          <img src={calendar} className="mcalendarDetaile" alt="logo" />
          <img src={pinPoint} className="mpinPointDetaile" alt="logo" />
          <img src={Frequency} className="mfrequencyDetaile" alt="logo" />
          <div className="mfrequencywordDetaileA">{activity.frequency}</div>
          <div className="madressDetaile">{activity.address}</div>
          <div className="cupoLimiteMobil">
            {activity.currentSignUps}/{activity.size}
          </div>
          <button className="minscribir" onClick={this.handleSubmit}>
            Sign up
          </button>
        </div>
      );
    } else {
      return <div> Error </div>;
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  const id = ownProps.match.params.id;
  const activitys = state.firestore.data.Actividades;
  const activity = activitys ? activitys[id] : null;

  return {
    activity: activity,
    profile: state.firebase.profile,
    signUpError: state.activitys.signUpError
  };
};
const mapDispatchToProps = dispatch => {
  return {
    signUpActivity: (activitys, id) => dispatch(signUpActivity(activitys, id)),
    clearSignUp: activity => dispatch(clearSignUp(activity))
  };
};
export default compose(
  connect(mapStateToProps, mapDispatchToProps),
  firestoreConnect([{ collection: "Actividades" }])
)(MactivityInfo);
