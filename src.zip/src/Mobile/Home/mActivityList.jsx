import React, { Component } from "react";
import { connect } from "react-redux";
import "../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import Loader from "react-loader-spinner";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "../mActivityDetaile";

class MActivityList extends Component {
  render() {
    const { activitys } = this.props;
    const { profile } = this.props;
    if (activitys) {
      return (
        <div className="pprruueebbaa3">
          <ul className="ulllll3">
            {activitys &&
              activitys.map(activity => {
                if (
                  profile.schoolCode == activity.school &&
                  activity.status == "Autorizado"
                ) {
                  return (
                    <Link to={"/activity/" + activity.id}>
                      <ActivityDetaile activity={activity} key={activity.id} />
                    </Link>
                  );
                }
              })}
          </ul>
        </div>
      );
    } else {
      return (
        <div className="spinnerMobile">
          <Loader
            type="TailSpin"
            color="rgba(231, 91, 16, 1.0)"
            height={150}
            width={150}
          />
        </div>
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.Actividades,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "Actividades" }])
)(MActivityList);
