import React from "react";
import "../HomeTest.css";
import DefaultActivityIcon from "../img/defaultActivityIcon.png";
import Backround from "../img/whiteBackround.png";

const ActivityDetaile = ({ activity }) => {
  if (activity.avatarURL === "") {
    var image = DefaultActivityIcon;
  } else {
    image = activity.avatarURL;
  }
  let startDate = activity.startDate.substring(5, 7);
  let endDate = activity.endDate.substring(5, 7);
  let action2;
  let action3;
  if (endDate == "01") {
    action3 = (
      <div className="mendDate">
        Jan-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "01") {
    action2 = (
      <div className="mstartDate">
        Jan-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "02") {
    action3 = (
      <div className="mendDate">
        Feb-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "02") {
    action2 = (
      <div className="mstartDate">
        Feb-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "03") {
    action3 = (
      <div className="mendDate">
        Mar-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "03") {
    action2 = (
      <div className="mstartDate">
        Mar-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "04") {
    action3 = (
      <div className="mendDate">
        Apr-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "04") {
    action2 = (
      <div className="mstartDate">
        Apr-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "05") {
    action3 = (
      <div className="mendDate">
        May-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "05") {
    action2 = (
      <div className="mstartDate">
        May-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "06") {
    action3 = (
      <div className="mendDate">
        Jun-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "06") {
    action2 = (
      <div className="mstartDate">
        Jun-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "07") {
    action3 = (
      <div className="mendDate">
        Jul-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "07") {
    action2 = (
      <div className="mstartDate">
        Jul-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "08") {
    action3 = (
      <div className="mendDate">
        Aug-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "08") {
    action2 = (
      <div className="mstartDate">
        Aug-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "09") {
    action3 = (
      <div className="mendDate">
        Sep-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "09") {
    action2 = (
      <div className="mstartDate">
        Sep-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "10") {
    action3 = (
      <div className="mendDate">
        Oct-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "10") {
    action2 = (
      <div className="mstartDate">
        Oct-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "11") {
    action3 = (
      <div className="mendDate">
        Nov-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "11") {
    action2 = (
      <div className="mstartDate">
        Nov-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  if (endDate == "12") {
    action3 = (
      <div className="mendDate">
        Dec-{activity.endDate.substring(8, 10)}-
        {activity.endDate.substring(0, 4)}
      </div>
    );
  }
  if (startDate == "12") {
    action2 = (
      <div className="mstartDate">
        Dec-{activity.startDate.substring(8, 10)}-
        {activity.startDate.substring(0, 4)} to
      </div>
    );
  }
  return (
    <li className="mStudentContainer">
      <div className="containers">
        <img src={Backround} className="mbackround" alt="logo" />

        <div>
          <img src={image} className="mphoto1" alt="logo" />
        </div>

        <div className="mPost">{activity.title}</div>

        <div className="mRectangle10Mobile"></div>

        <div className="mDate">
          {action2} {action3}
        </div>
        <div className="mPruebaaData">Activity #{activity.activityCode}</div>
      </div>
    </li>
  );
};

export default ActivityDetaile;
