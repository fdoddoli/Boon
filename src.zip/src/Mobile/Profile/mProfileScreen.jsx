import React, { Component } from "react";
import "../../HomeTest.css";
import firebase from "firebase";
import Cropper from "react-cropper";
import { connect } from "react-redux";
import "../../App.css";
import { createActivity } from "../../Actions/activityActions";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import daniel from "../../img/daniel.jpg";
import MUpcomingActivityList from "./Upcoming Activity/mUpcomingActivityList";

//Mobile Profile Screen
class MProfileScreen extends Component {
  state = {};
  logout = () => {
    firebase.auth().signOut();
  };

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = e => {
    e.preventDefault();
    this.props.createActivity(this.state);
  };

  render() {
    const { profile } = this.props;
    let action;
    let action2;
    let action3;
    if (profile.avatarURL != "") {
      action = profile.avatarURL;
    } else {
      action = daniel;
    }
    if (profile.type == "Hours") {
      action2 = "HOURS";
    } else {
      action2 = "ATTENDENCES";
    }
    if (profile.type == "Hours") {
      action3 = profile.horas;
    } else {
      action3 = profile.asistencias;
    }
    return (
      <div>
        <img src={action} className="pmcontainer" alt="logo" />
        <div className="pmName">{profile.name}</div>
        <div className="pmEmail">{profile.email}</div>
        <div className="pmAtt">{action2}</div>
        <div className="pmAttNum">{action3}</div>
        <div className="uppComing">Upcoming Activities</div>
        <div className="check12345678">
          <MUpcomingActivityList />
        </div>
      </div>
    );
  }
}
function mapStateToProps(state) {
  return {
    profile: state.firebase.profile
  };
}

export default connect(mapStateToProps)(MProfileScreen);
