import React, { Component } from "react";
import { connect } from "react-redux";
import "../../../HomeTest.css";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Redirect
} from "react-router-dom";
import ActivityDetaile from "../../mActivityDetaile";

class MUpcomingActivityList extends Component {
  render() {
    const { activitys } = this.props;
    const { profile } = this.props;
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    today = yyyy + "-" + mm + "-" + dd;
    return (
      <div className="pprruueebbaa3">
        <ul className="ulllll3">
          {activitys &&
            activitys.map(activity => {
              if (
                activity.studentName == profile.name &&
                today < activity.endDate
              ) {
                return (
                  <Link to={"upcomingActivity/" + activity.id}>
                    <ActivityDetaile activity={activity} key={activity.id} />
                  </Link>
                );
              }
            })}
        </ul>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    activitys: state.firestore.ordered.ActividadesyUsuarios,
    profile: state.firebase.profile
  };
}

export default compose(
  connect(mapStateToProps),
  firestoreConnect([{ collection: "ActividadesyUsuarios" }])
)(MUpcomingActivityList);
