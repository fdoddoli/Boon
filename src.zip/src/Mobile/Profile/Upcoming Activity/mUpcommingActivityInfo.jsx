import React, { Component } from "react";
import "../../../HomeTest.css";
import DefaultActivityIcon from "../../../img/defaultActivityIcon.png";
import { connect } from "react-redux";
import { firestoreConnect } from "react-redux-firebase";
import { compose } from "redux";
import calendar from "../../../img/calendar.png";
import pinPoint from "../../../img/pinPoint.png";
import { signUpActivity } from "../../../Actions/activityActions";

// var googleMapsClient = require('@google/maps').createClient({
//  key: 'AIzaSyDCK7yOIMkvuYFh7_Dk-9DwsspqxR_OqsA'
// });

class UpcommingactivityInfo extends Component {
  state = {
    id: this.props.match.params.id,
    image: "",
    title: "",
    desc: "",
    size: "",
    address: "",
    date: "",
    time: "",
    repeat: "",
    school: ""
  };

  handleSubmit = e => {
    const { activity } = this.props;
    this.props.signUpActivity(activity);
  };

  render() {
    const { activity } = this.props;
    const { profile } = this.props;
    let hr;

    if (activity) {
      if (activity.avatarURL === "") {
        var image = DefaultActivityIcon;
      } else {
        image = activity.avatarURL;
      }
      if (profile.type === "Hours") {
        hr = <div className="mtimeDetaile">{activity.hours} hrs</div>;
      }
      return (
        <div>
          <img src={image} className="mdfotoDetaile" alt="logo" />
          <div className="mtitleSetaile">{activity.title}</div>
          {hr}
          <div className="mddescDetaile">{activity.desc}</div>
          <div className="mdateDetaile">
            {activity.startDate} - {activity.endDate}
          </div>

          <img src={calendar} className="mcalendarDetaile" alt="logo" />
          <img src={pinPoint} className="mpinPointDetaile" alt="logo" />
          <div className="madressDetaile">{activity.address}</div>
          <button className="minscribir" onClick={this.handleSubmit}>
            Sign up
          </button>
        </div>
      );
    } else {
      return <div> Error </div>;
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  const id = ownProps.match.params.id;
  const activitys = state.firestore.data.ActividadesyUsuarios;
  const activity = activitys ? activitys[id] : null;

  return {
    activity: activity,
    profile: state.firebase.profile
  };
};
const mapDispatchToProps = dispatch => {
  return {
    signUpActivity: activitys => dispatch(signUpActivity(activitys))
  };
};
export default compose(
  connect(
    mapStateToProps,
    mapDispatchToProps
  ),
  firestoreConnect([{ collection: "ActividadesyUsuarios" }])
)(UpcommingactivityInfo);
